<?php
return array (
  'Add files' => 'Dodaj pliki',
  'Allows the user to modify or delete any files.' => 'Zezwól użytkownikom na modyfikacje i usuwanie plików.',
  'Allows the user to upload new files and create folders' => 'Zezwól użytkownikom na wgrywanie nowych plików i tworzenie folderów',
  'Manage files' => 'Zarządzaj plikami',
);
