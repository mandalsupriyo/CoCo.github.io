<?php
return array (
  'Folder ID' => 'ID datoteke',
);
