<?php
return array (
  'Add files' => 'Dodaj datoteke',
  'Allows the user to modify or delete any files.' => 'Korisniku omogućuje izmjenu ili brisanje svih datoteka.',
  'Allows the user to upload new files and create folders' => 'Korisniku omogućuje prijenos novih datoteka i stvaranje mapa',
  'Manage files' => 'Upravljaj datotekama',
);
