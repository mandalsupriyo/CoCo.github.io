<?php
return array (
  'Are you really sure to delete this version?' => 'Êtes-vous sûr·e de supprimer cette version ?',
  'The version "{versionDate}" could not be deleted!' => 'La version "{versionDate}" n’a pas pu être supprimée !',
  'The version "{versionDate}" has been deleted.' => 'La version "{versionDate}" a été supprimée.',
);
