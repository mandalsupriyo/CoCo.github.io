<?php
return array (
  'Description' => 'Apraksts',
  'Parent Folder ID' => '',
  'Title' => 'Nosaukums',
);
