<?php
return array (
  'Description' => '',
  'Parent Folder ID' => '',
  'Title' => 'כותרת',
);
