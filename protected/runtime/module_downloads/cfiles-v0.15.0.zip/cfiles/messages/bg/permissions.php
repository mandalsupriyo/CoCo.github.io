<?php
return array (
  'Add files' => 'Добави файлове',
  'Allows the user to modify or delete any files.' => 'Позволи на потребителя да променя или изтрива всички файлове.',
  'Allows the user to upload new files and create folders' => 'Позволи на потребителя да качва нови файлове и да създава папки',
  'Manage files' => 'Управление на файлове',
);
