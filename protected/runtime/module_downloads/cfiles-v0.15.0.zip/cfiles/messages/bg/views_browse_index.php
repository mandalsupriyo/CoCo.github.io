<?php
return array (
  'Could not save file %title%. ' => 'Файлът %title% беше неуспешно запазен.',
);
