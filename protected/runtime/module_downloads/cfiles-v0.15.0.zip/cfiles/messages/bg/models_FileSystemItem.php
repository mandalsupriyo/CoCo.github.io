<?php
return array (
  'Downloads' => 'Изтегляния',
  'Is Public' => 'Е публичен',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Забележка: Промените във видимостта на папките ще бъдат наследени от всички съдържащи се файлове и папки.',
);
