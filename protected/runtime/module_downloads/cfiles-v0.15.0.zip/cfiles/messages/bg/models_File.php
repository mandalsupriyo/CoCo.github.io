<?php
return array (
  'Folder ID' => 'Идентификационен номер на папката',
);
