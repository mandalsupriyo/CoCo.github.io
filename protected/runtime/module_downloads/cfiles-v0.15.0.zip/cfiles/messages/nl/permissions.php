<?php
return array (
  'Add files' => 'Voeg bestanden toe',
  'Allows the user to modify or delete any files.' => 'Laat de gebruiker bestanden wijzigen en verwijderen.',
  'Allows the user to upload new files and create folders' => 'Laat de gebruiker nieuwe bestanden uploaden en mappen maken',
  'Manage files' => 'Bestanden beheren',
);
