<?php
return array (
  'Description' => 'Descripción',
  'Parent Folder ID' => 'ID de la Carpeta raíz',
  'Title' => 'Título',
);
