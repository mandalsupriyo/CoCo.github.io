<?php
return array (
  'Are you really sure to delete this version?' => '¿Estás seguro de que quieres borrar esta versión?',
  'The version "{versionDate}" could not be deleted!' => '¡La versión "{versionDate}" no puede borrarse!',
  'The version "{versionDate}" has been deleted.' => 'La versión "{versionDate}" ha sido borrada.',
);
