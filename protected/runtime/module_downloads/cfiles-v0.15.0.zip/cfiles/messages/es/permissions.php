<?php
return array (
  'Add files' => 'Agregar archivos',
  'Allows the user to modify or delete any files.' => 'Permite a los usuarios modificar o eliminar cualquier archivo.',
  'Allows the user to upload new files and create folders' => 'Permite a los usuarios subir nuevos archivos y crear carpetas.',
  'Manage files' => 'Organizar archivos.',
);
