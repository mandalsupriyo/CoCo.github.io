<?php
return array (
  'Downloads' => 'Descargas',
  'Is Public' => 'Es público',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Nota: Los cambios de visibilidad de las carpetas, serán incorporados por todos los archivos y carpetas contenidos.',
);
