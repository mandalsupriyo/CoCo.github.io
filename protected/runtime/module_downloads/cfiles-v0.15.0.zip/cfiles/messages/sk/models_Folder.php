<?php
return array (
  'Description' => '',
  'Parent Folder ID' => '',
  'Title' => '제목',
);
