<?php
return array (
  'Add files' => 'เพิ่มไฟล์',
  'Allows the user to modify or delete any files.' => 'อนุญาตให้ผู้ใช้แก้ไขหรือลบไฟล์ใดๆ',
  'Allows the user to upload new files and create folders' => 'อนุญาตให้ผู้ใช้อัปโหลดไฟล์ใหม่และสร้างโฟลเดอร์',
  'Manage files' => 'จัดการไฟล์',
);
