<?php
return array (
  'Description' => 'คำอธิบาย',
  'Parent Folder ID' => 'รหัสโฟลเดอร์หลักผู้ปกครอง',
  'Title' => 'หัวข้อ',
);
