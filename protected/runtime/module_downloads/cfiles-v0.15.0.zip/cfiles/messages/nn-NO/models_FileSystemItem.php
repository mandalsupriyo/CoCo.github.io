<?php

return [
    'Downloads' => '',
    'Is Public' => '',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '',
];
