<?php

return [
    'Are you really sure to delete this version?' => '',
    'The version "{versionDate}" could not be deleted!' => '',
    'The version "{versionDate}" has been deleted.' => '',
];
