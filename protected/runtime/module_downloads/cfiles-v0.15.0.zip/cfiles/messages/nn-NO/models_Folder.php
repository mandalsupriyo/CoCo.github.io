<?php
return array (
  'Description' => '',
  'Parent Folder ID' => '',
  'Title' => 'Tittel',
);
