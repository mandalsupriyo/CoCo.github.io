<?php
return array (
  'Description' => 'توضيج',
  'Parent Folder ID' => '',
  'Title' => 'العنوان',
);
