<?php
return array (
  'Description' => 'Beskrivelse',
  'Parent Folder ID' => '',
  'Title' => 'Titel',
);
