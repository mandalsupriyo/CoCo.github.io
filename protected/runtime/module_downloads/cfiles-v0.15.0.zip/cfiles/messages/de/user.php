<?php
return array (
  'Are you really sure to delete this version?' => 'Möchtest du diese Version wirklich löschen?',
  'The version "{versionDate}" could not be deleted!' => 'Die Version "{versionDate}" konnte nicht gelöscht werden!',
  'The version "{versionDate}" has been deleted.' => 'Die Version "{versionDate}" wurde gelöscht.',
);
