<?php
return array (
  'Could not save file %title%. ' => 'Kunde inte spara filen %title%.',
);
