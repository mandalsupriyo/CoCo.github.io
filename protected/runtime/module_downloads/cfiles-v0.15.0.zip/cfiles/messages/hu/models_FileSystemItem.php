<?php
return array (
  'Downloads' => 'Letöltések',
  'Is Public' => 'Nyilvános',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Megjegyzés: a mappa láthatóságának megváltoztatása a benne lévő összes fájlra és mappára is érvényes.',
);
