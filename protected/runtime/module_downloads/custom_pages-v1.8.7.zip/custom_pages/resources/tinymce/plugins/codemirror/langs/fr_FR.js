tinymce.addI18n('fr_FR',{
	'HTML source code': 'Code source HTML',
	'Start search': 'Rechercher',
	'Find next': 'Chercher suiv.',
	'Find previous': 'Chercher préc.',
	'Replace': 'Replace',
	'Replace all': 'Replace all'
});
