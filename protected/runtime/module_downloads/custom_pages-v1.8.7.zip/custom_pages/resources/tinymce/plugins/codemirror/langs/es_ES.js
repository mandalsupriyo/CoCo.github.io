tinymce.addI18n('es_ES',{
	'HTML source code': 'Código fuente HTML',
	'Start search': 'Buscar',
	'Find next': 'Siguiente',
	'Find previous': 'Anterior',
	'Replace': 'Reemplazar',
	'Replace all': 'Reemplazar todo'
});
