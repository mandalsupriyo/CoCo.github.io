[![Test Status](https://github.com/humhub/polls/actions/workflows/php-test-master.yml/badge.svg)](https://github.com/humhub/polls/actions/workflows/php-test-master.yml)

# Polls

Stop discussing, let the votes speak for themselves. Our Polls module allows you to resolve disputes quickly. Let the majority decide, or just get an opinion on your urgent questions. 

## Overviews

- Offer single or multiple choice
- Hide the results until the poll is closed
- Vote anonymously
- Discuss the results in the comments
