<?php
return array (
  'Access denied!' => 'Accès refusé.',
  'Anonymous poll!' => 'Sondage anonyme.',
  'Could not load poll!' => 'Impossible de charger le sondage.',
  'Invalid answer!' => 'Réponse invalide.',
  'Users voted for: <strong>{answer}</strong>' => 'Les utilisateurs ont choisi : <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Réponse multiple impossible.',
  'You have insufficient permissions to perform that operation!' => 'Vous n\'avez pas la permission pour effectuer cette opération.',
);
