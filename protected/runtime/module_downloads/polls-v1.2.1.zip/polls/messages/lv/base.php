<?php

return [
    'Allows to start polls.' => 'Atļauj uzsākt aptauju.',
    'Answers' => 'Atbildes',
    'Cancel' => 'Atcelt',
    'Polls' => 'Aptaujas',
    'Save' => 'Saglabāt',
    'Allows the user to create polls' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
