<?php

return [
    'Answers' => 'پاسخ‌ها',
    'Cancel' => 'انصراف',
    'Polls' => 'نظرسنجی‌ها',
    'Save' => 'ذخیره',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
