<?php
return array (
  'Add answer...' => '',
  'Anonymous Votes?' => '',
  'Description' => 'توضيج',
  'Display answers in random order?' => '',
  'Edit answer (empty answers will be removed)...' => '',
  'Edit your poll question...' => '',
  'Hide results until poll is closed?' => '',
  'Question' => '',
);
