<?php
return array (
  'Allows the user to create polls' => '',
  'Allows to start polls.' => '',
  'Answers' => '',
  'At least one answer is required' => '',
  'Cancel' => '取消',
  'Create poll' => '',
  'Polls' => '',
  'Save' => '儲存',
);
