<?php

return [
    'Answers' => 'Jawaban',
    'Cancel' => 'Batal',
    'Polls' => 'Pemungutan Suara',
    'Save' => 'Simpan',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
