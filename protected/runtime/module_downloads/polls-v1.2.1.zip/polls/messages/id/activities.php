<?php
return array (
  'Polls' => 'Pemungutan Suara',
  'Whenever someone participates in a poll.' => '',
);
