<?php

return [
    'Again? ;Weary;' => 'Ещё раз? ;Weary;',
    'Club A Steakhouse' => 'Клуб «Стейкхаус»',
    'Pisillo Italian Panini' => 'Итальянское Панини «Pisillo»',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Сейчас мы планируем нашу следующую встречу, и мы хотели бы узнать от Вас, куда Вы хотели бы пойти?',
    'To Daniel' => 'Для Даниэля',
    'Why don\'t we go to Bemelmans Bar?' => 'Почему бы нам не пойти в бар «Bemelmans?»',
    'Location of the next meeting' => '',
];
