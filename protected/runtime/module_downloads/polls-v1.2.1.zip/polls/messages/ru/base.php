<?php

return [
    'Allows to start polls.' => 'Разрешить создавать опросы',
    'Answers' => 'Ответы',
    'At least one answer is required' => 'Требуется хотя бы один ответ',
    'Cancel' => 'Отменить',
    'Polls' => 'Опросы',
    'Save' => 'Сохранить',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
