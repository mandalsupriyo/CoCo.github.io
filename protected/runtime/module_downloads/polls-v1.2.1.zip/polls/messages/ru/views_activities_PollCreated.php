<?php
return array (
  '{userName} created a new {question}.' => '{userName} создал(а) новый {question}.',
);
