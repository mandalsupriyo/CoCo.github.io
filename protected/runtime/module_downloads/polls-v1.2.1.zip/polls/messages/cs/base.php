<?php

return [
    'Allows to start polls.' => 'Povolení vytváření anket',
    'Answers' => '"Odpovědi"',
    'Cancel' => 'Zrušit',
    'Polls' => 'Ankety',
    'Save' => 'Uložit',
    'Allows the user to create polls' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
