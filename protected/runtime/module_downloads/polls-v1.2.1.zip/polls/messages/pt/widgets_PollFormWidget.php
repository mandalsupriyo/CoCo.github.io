<?php
return array (
  'Ask' => 'Pergunta',
);
