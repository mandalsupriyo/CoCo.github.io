<?php
return array (
  'Answers' => 'Opções',
  'Description' => 'Descrição',
  'Multiple answers per user' => 'Várias opções por pessoa',
  'Please specify at least {min} answers!' => 'Por favor especifica pelo menos {min} opções!',
  'Poll' => 'Questão',
  'Question' => 'Questão',
);
