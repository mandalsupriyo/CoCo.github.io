<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Merk:</strong> Resultatene er skjult til meningsmålingen avsluttes av moderator.',
  'Anonymous' => 'Anonym',
  'Closed' => 'Lukket',
  'Complete Poll' => 'Ferdigstill meningsmåling',
  'Reopen Poll' => 'Gjenåpne meningsmåling',
  'Reset my vote' => 'Tilbakestill min stemme',
  'Vote' => 'Stem',
  'and {count} more vote for this.' => 'og {count} stemte på dette.',
  'votes' => 'stemmer',
);
