<?php

return [
    'Again? ;Weary;' => 'Igjen? ; Weary',
    'Club A Steakhouse' => 'Bestem et sted å møtes',
    'Pisillo Italian Panini' => 'på hjørnet',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Akkurat nå er vi i planleggingen av neste møte, vi ønsker å vite hvor vi skal møtes?',
    'To Daniel' => 'Hos Daniel',
    'Why don\'t we go to Bemelmans Bar?' => 'Hva med nærmeste bar?',
    'Location of the next meeting' => '',
];
