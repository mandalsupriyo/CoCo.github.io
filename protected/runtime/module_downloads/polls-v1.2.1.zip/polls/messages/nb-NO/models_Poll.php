<?php
return array (
  'Answers' => 'Svar',
  'Description' => 'Beskrivelse',
  'Multiple answers per user' => 'Flere svar pr bruker',
  'Please specify at least {min} answers!' => 'Vennligst spesifisér minst {min} svaralternativer!',
  'Poll' => 'Spørsmål',
  'Question' => 'Spørsmål',
);
