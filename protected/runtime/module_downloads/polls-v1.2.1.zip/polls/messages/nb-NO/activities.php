<?php
return array (
  'Polls' => 'Meningsmålinger',
  'Whenever someone participates in a poll.' => '',
);
