<?php
return array (
  '{userName} answered the {question}.' => '{userName} отговори на {question}.',
);
