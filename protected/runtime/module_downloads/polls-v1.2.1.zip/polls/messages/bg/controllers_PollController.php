<?php
return array (
  'Access denied!' => 'Достъп отказан!',
  'Anonymous poll!' => 'Анонимна анкета!',
  'Could not load poll!' => 'Анкета не може да бъде заредена!',
  'Invalid answer!' => 'Невалиден отговор!',
  'Users voted for: <strong>{answer}</strong>' => 'Потребителите гласуваха за: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Гласуването за множество отговори е деактивирано!',
  'You have insufficient permissions to perform that operation!' => 'Нямате достатъчно разрешения за извършване на тази операция!',
);
