<?php
return array (
  'User who vote this' => 'Потребител, който гласува за това',
);
