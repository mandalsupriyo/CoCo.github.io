<?php
return array (
  'Allows the user to create polls' => 'Позволява на потребителя да създава анкети',
  'Allows to start polls.' => 'Позволява стартиране на анкети.',
  'Answers' => 'Отговори',
  'At least one answer is required' => 'Изисква се поне един отговор',
  'Cancel' => 'Отказ',
  'Create poll' => 'Създаване на анкета',
  'Polls' => 'Анкети',
  'Save' => 'Запази',
);
