<?php
return array (
  'Ask' => 'Попитай',
);
