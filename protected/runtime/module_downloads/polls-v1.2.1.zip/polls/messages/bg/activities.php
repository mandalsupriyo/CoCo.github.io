<?php
return array (
  'Polls' => 'Анкети',
  'Whenever someone participates in a poll.' => 'Винаги, когато някой участва в анкета.',
);
