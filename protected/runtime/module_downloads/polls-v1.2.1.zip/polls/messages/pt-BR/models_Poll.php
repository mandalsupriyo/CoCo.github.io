<?php
return array (
  'Answers' => 'Respostas',
  'Description' => 'Descrição',
  'Multiple answers per user' => 'Múltiplas respostas por usuário',
  'Please specify at least {min} answers!' => 'Especifique pelo menos {min} respostas!',
  'Poll' => 'Pergunta',
  'Question' => 'Pergunta',
);
