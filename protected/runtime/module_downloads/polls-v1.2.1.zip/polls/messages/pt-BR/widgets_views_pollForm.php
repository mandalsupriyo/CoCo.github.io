<?php
return array (
  'Add answer...' => 'Adicionar resposta...',
  'Anonymous Votes?' => 'Votos Anônimos?',
  'Description' => 'Descrição',
  'Display answers in random order?' => 'Mostrar respostas em ordem aleatória?',
  'Edit answer (empty answers will be removed)...' => 'Editar resposta (as respostas vazias serão removidas)...',
  'Edit your poll question...' => 'Editar a pergunta da sua enquete ...',
  'Hide results until poll is closed?' => 'Ocultar resultados até que a votação seja encerrada?',
  'Question' => 'Pergunta',
);
