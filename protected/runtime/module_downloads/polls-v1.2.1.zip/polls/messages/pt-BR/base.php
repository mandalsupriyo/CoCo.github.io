<?php
return array (
  'Allows the user to create polls' => 'Permite ao usuário criar enquetes',
  'Allows to start polls.' => 'Permite iniciar enquetes.',
  'Answers' => 'Respostas',
  'At least one answer is required' => 'É necessária pelo menos uma resposta',
  'Cancel' => 'Cancelar',
  'Create poll' => 'Criar enquete',
  'Polls' => 'Enquete',
  'Save' => 'Salvar',
);
