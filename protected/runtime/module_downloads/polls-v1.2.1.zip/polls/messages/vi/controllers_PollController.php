<?php
return array (
  'Access denied!' => 'Từ chối truy cập!',
  'Anonymous poll!' => 'Biểu quyết vô danh!',
  'Could not load poll!' => 'Không thể tải biểu quyết!',
  'Invalid answer!' => 'Câu trả lời không hợp lệ!',
  'Users voted for: <strong>{answer}</strong>' => 'Thành viên đã bỏ phiếu cho: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Bỏ phiếu cho nhiều câu trả lời đã bị vô hiệu hóa!',
  'You have insufficient permissions to perform that operation!' => 'Bạn không đủ thẩm quyền thực hiện hành động này!',
);
