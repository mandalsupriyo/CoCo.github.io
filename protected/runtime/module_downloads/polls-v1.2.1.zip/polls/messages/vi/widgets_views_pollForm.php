<?php
return array (
  'Add answer...' => 'Thêm câu trả lời...',
  'Anonymous Votes?' => 'Cho phép biểu quyết vô danh?',
  'Description' => 'Miêu tả',
  'Display answers in random order?' => 'Hiển thị câu trả lời theo thứ tự ngẫu nhiên?',
  'Edit answer (empty answers will be removed)...' => 'Chỉnh sửa câu hỏi (câu hỏi trống sẽ bị xóa bỏ)...',
  'Edit your poll question...' => 'Chỉnh sửa câu hỏi biểu quyết...',
  'Hide results until poll is closed?' => 'Ẩn kết quả cho tới khi phiên biểu quyết được đóng?',
  'Question' => 'Câu hỏi',
);
