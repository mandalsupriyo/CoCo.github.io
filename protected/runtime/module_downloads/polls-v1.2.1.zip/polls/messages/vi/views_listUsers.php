<?php
return array (
  'User who vote this' => 'Người dùng bỏ phiếu điều này',
);
