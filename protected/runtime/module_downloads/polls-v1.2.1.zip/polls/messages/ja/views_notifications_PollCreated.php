<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} さんがアンケートを作成しました、あなたの回答を希望しています。',
);
