<?php
return array (
  'Answers' => '回答',
  'Description' => '説明',
  'Multiple answers per user' => '複数回答を許可する',
  'Please specify at least {min} answers!' => '{min}問以上の回答を指定してください。',
  'Poll' => 'アンケート',
  'Question' => 'アンケート',
);
