<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>アンケートはまだありません。</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>アンケートはまだありません。</b><br />最初に作成してください...',
  'Asked by me' => '私が質問したもの',
  'No answered yet' => 'まだ回答がないもの',
  'Only private polls' => '非公開アンケート',
  'Only public polls' => '公開アンケート',
);
