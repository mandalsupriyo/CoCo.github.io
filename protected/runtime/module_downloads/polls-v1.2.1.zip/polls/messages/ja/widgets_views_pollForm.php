<?php
return array (
  'Add answer...' => '回答を追加...',
  'Anonymous Votes?' => '匿名の投票',
  'Description' => '説明',
  'Display answers in random order?' => '回答をランダムな順序で表示する',
  'Edit answer (empty answers will be removed)...' => '回答を編集（空欄の回答は削除されます）...',
  'Edit your poll question...' => '質問を編集...',
  'Hide results until poll is closed?' => 'アンケートを終了するまで結果を表示しない',
  'Question' => 'アンケート',
);
