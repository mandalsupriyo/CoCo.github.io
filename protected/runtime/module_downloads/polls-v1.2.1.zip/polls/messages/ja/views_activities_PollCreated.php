<?php
return array (
  '{userName} created a new {question}.' => '{userName}さんが新しい {question} を作成しました。',
);
