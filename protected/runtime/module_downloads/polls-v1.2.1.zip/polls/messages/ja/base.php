<?php
return array (
  'Allows the user to create polls' => 'ユーザーが投票を作成できるようにします',
  'Allows to start polls.' => '投票形式のアンケート（世論調査）を開始できます。',
  'Answers' => '回答',
  'At least one answer is required' => '1つ以上の回答が必要です。',
  'Cancel' => 'キャンセル',
  'Create poll' => '投票を作成する',
  'Polls' => 'アンケート',
  'Save' => '保存',
);
