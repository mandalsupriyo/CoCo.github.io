<?php
return array (
  'Polls' => '投票',
  'Whenever someone participates in a poll.' => '',
);
