<?php

return [
    'Again? ;Weary;' => '又来？',
    'Club A Steakhouse' => '俱乐部A的牛排',
    'Pisillo Italian Panini' => '意大利三明治',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => '现在，我们在规划下次聚会，我们想了解一下，你想去哪里？',
    'To Daniel' => '去丹尼尔',
    'Why don\'t we go to Bemelmans Bar?' => '我们为什么不去比梅尔曼斯？',
    'Location of the next meeting' => '',
];
