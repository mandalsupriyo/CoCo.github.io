<?php
return array (
  'Allows the user to create polls' => '',
  'Allows to start polls.' => '',
  'Answers' => '',
  'At least one answer is required' => '',
  'Cancel' => 'Anulo',
  'Create poll' => '',
  'Polls' => '',
  'Save' => '',
);
