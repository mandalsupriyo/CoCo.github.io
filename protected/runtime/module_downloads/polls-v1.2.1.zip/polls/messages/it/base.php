<?php
return array (
  'Allows the user to create polls' => 'Consente all\'utente di creare sondaggi',
  'Allows to start polls.' => 'Consente di iniziare un sondaggio.',
  'Answers' => 'Risposte',
  'At least one answer is required' => 'E\' necessaria almeno ina risposta.',
  'Cancel' => 'Annulla',
  'Create poll' => 'Crea sondaggio',
  'Polls' => 'Sondaggi',
  'Save' => 'Salva',
);
