<?php
return array (
  'Polls' => 'Stembussen',
  'Whenever someone participates in a poll.' => 'Elke keer dat iemand deelneemt aan een stembus',
);
