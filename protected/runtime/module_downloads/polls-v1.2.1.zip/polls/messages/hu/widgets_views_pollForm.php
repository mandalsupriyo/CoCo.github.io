<?php
return array (
  'Add answer...' => 'Válasz hozzáadása...',
  'Anonymous Votes?' => 'Anonim szavazatok?',
  'Description' => 'Leírás',
  'Display answers in random order?' => 'Válaszok megjelenítése véletlenszerű sorrendben?',
  'Edit answer (empty answers will be removed)...' => 'Válasz módosítása (az üres válaszok eltávolításra kerülnek)',
  'Edit your poll question...' => 'Kérdés módosítása...',
  'Hide results until poll is closed?' => 'Eredmények elrejtése a szavazás lezárásáig?',
  'Question' => 'Kérdés',
);
