<?php
return array (
  'Access denied!' => 'Hozzáférés megtagadva!',
  'Anonymous poll!' => 'Anonim szavazás!',
  'Could not load poll!' => 'Szavazás nem tölthető be!',
  'Invalid answer!' => 'Érvénytelen válasz!',
  'Users voted for: <strong>{answer}</strong>' => 'Felhasználók választása: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Több válaszra nem lehet szavazni!',
  'You have insufficient permissions to perform that operation!' => 'Elégtelen jogosultságaid vannak a művelet végrehajtásához!',
);
