<?php
return array (
  'Allows the user to create polls' => 'A felhasználóknak engedélyezi a szavazások létrehozását',
  'Allows to start polls.' => 'Engedélyezi szavazás indítását.',
  'Answers' => 'Válaszok',
  'At least one answer is required' => 'Egy válaszra legalább szükség van',
  'Cancel' => 'Mégsem',
  'Create poll' => 'Szavazás létrehozása',
  'Polls' => 'Szavazás',
  'Save' => 'Mentés',
);
