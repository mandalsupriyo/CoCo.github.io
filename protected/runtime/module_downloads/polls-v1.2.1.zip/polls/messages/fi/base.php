<?php

return [
    'Allows to start polls.' => 'Antaa luoda kyselyitä',
    'Answers' => 'Vastausta',
    'At least one answer is required' => 'Tarvitaan vähintään yksi vastaus',
    'Cancel' => 'Peruuta',
    'Polls' => 'Kyselyt',
    'Save' => 'Tallenna',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
