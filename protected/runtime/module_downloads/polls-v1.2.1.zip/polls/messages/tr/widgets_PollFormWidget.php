<?php
return array (
  'Ask' => 'Sor',
);
