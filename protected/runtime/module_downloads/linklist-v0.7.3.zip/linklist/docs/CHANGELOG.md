Changelog
=========

0.7.3 (November 18, 2022)
------------------
- Removed deprecated `$space->isModuleEnabled()` calls

0.7.2 (November 18, 2022)
-------------------------
- Refactored old container setting usage

0.7.1 (April 26, 2022)
----------------------
- Enh #4823: Remove CHTML/CActiveForm usages

0.7.0 (April 26, 2020)
------------------------
- Enh #4751: Hide separator between content links
- Fix #42: Fix permissions


0.6.0 (November 4, 2020)
------------------------
- Enh #38: Wall Stream Layout Migration for HumHub 1.7+ 


0.5.9 (February 19, 2020)
---------------------------
- Fix #36: XSS vulnerability in link url 
- Enh: Translation updates


0.5.8 (October 14, 2018)
---------------------------
- Fix: Added menu icon
- Enh: Translation updates

