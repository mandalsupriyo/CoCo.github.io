# Link List

Adds a link list to spaces or user profiles.

**Features**

- Add links and communicate about with other users
- Organize links in categories
