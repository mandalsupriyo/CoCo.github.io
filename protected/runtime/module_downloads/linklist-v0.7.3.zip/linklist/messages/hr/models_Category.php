<?php
return array (
  'Description' => 'Opis',
  'Sort Order' => 'Redoslijed',
  'Title' => 'Naziv',
);
