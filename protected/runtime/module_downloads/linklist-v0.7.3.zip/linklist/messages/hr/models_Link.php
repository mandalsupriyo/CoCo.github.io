<?php
return array (
  'Category' => 'Kategorija',
  'Description' => 'Opis',
  'Sort Order' => 'Redoslijed',
  'Title' => 'Naziv',
);
