<?php

return [
    'Category' => '',
    'Description' => '',
    'Sort Order' => '',
    'Title' => '',
];
