<?php
return array (
  'Description' => 'Beschreibung',
  'Sort Order' => 'Sortierreihenfolge',
  'Title' => 'Titel',
);
