<?php
return array (
  'Category' => 'Kategorie',
  'Description' => 'Beschreibung',
  'Sort Order' => 'Sortierreihenfolge',
  'Title' => 'Titel',
);
