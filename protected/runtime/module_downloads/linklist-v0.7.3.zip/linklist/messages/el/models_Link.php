<?php
return array (
  'Category' => '',
  'Description' => 'Περιγραφή',
  'Sort Order' => 'Σειρά ταξινόμησης',
  'Title' => 'Τίτλος',
);
