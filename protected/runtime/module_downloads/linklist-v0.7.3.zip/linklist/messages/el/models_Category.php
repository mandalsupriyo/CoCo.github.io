<?php
return array (
  'Description' => 'Περιγραφή',
  'Sort Order' => 'Σειρά ταξινόμησης',
  'Title' => 'Τίτλος',
);
