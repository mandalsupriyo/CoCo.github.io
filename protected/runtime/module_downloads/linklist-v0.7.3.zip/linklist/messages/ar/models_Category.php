<?php
return array (
  'Description' => 'توضيج',
  'Sort Order' => '',
  'Title' => 'العنوان',
);
