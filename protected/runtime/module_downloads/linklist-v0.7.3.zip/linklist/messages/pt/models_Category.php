<?php
return array (
  'Description' => 'Descrição',
  'Sort Order' => 'Ordenação',
  'Title' => 'Título',
);
