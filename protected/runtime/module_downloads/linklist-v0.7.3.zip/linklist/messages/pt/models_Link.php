<?php
return array (
  'Category' => 'Categoria',
  'Description' => 'Descrição',
  'Sort Order' => 'Ordenação',
  'Title' => 'Título',
);
