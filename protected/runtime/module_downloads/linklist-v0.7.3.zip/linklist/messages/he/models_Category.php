<?php
return array (
  'Description' => '',
  'Sort Order' => '',
  'Title' => 'כותרת',
);
