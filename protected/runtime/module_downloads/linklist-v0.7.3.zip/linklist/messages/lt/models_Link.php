<?php
return array (
  'Category' => '',
  'Description' => 'Aprašymas',
  'Sort Order' => 'Rūšiavimo tvarka',
  'Title' => 'Pavadinimas',
);
