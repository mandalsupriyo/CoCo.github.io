<?php
return array (
  'Description' => 'Apraksts',
  'Sort Order' => '',
  'Title' => 'Nosaukums',
);
