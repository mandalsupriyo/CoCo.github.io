<?php
return array (
  'Category' => '',
  'Description' => 'Apraksts',
  'Sort Order' => '',
  'Title' => 'Nosaukums',
);
