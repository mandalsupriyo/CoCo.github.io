<?php
return array (
  'Category' => 'Catégorie',
  'Description' => 'Description',
  'Sort Order' => 'Ordre de tri',
  'Title' => 'Titre',
);
