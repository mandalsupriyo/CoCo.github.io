<?php
return array (
  'Category' => 'Kategoria',
  'Description' => 'Opis',
  'Sort Order' => 'Sortuj',
  'Title' => 'Tytuł',
);
