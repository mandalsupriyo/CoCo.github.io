<?php
return array (
  'Description' => 'Descrizione',
  'Sort Order' => 'Ordinamento',
  'Title' => 'Titolo',
);
