<?php
return array (
  'Description' => 'Beschrijving',
  'Sort Order' => 'Sorteervolgorde',
  'Title' => 'Titel',
);
