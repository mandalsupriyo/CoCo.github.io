<?php
return array (
  'Category' => 'Kategori',
  'Description' => 'Açıklama',
  'Sort Order' => 'Sıralama',
  'Title' => 'Başlık',
);
