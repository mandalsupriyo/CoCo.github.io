<?php
return array (
  'Category' => 'カテゴリ',
  'Description' => '説明',
  'Sort Order' => '並べ替え順序',
  'Title' => 'タイトル',
);
