<?php
return array (
  'Description' => 'Descripción',
  'Sort Order' => 'Ordenar por',
  'Title' => 'Titulo',
);
