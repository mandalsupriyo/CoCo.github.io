<?php
return array (
  'Category' => 'Categoría',
  'Description' => 'Descripción',
  'Sort Order' => 'Ordenar por',
  'Title' => 'Titulo',
);
