<?php
return array (
  'Description' => 'Descripción',
  'Sort Order' => '',
  'Title' => 'Titulek',
);
