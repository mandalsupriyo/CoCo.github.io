<?php
return array (
  'Category' => 'Categoría',
  'Description' => 'Descripción',
  'Sort Order' => '',
  'Title' => 'Titulek',
);
