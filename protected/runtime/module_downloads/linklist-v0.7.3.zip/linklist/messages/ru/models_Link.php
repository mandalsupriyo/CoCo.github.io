<?php
return array (
  'Category' => 'Категория',
  'Description' => 'Описание',
  'Sort Order' => 'Порядок сортировки',
  'Title' => 'Заголовок',
);
