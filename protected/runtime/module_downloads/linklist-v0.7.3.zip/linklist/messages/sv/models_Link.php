<?php
return array (
  'Category' => 'Kategori',
  'Description' => 'Beskrivning',
  'Sort Order' => 'Sorteringsordning',
  'Title' => 'Rubrik',
);
