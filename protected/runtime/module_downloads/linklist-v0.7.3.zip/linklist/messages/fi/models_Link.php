<?php
return array (
  'Category' => 'Kategoria',
  'Description' => 'Kuvaus',
  'Sort Order' => 'Lajittelujärjestys',
  'Title' => 'Otsikko',
);
