<?php
return array (
  'Description' => 'Kuvaus',
  'Sort Order' => 'Lajittelujärjestys',
  'Title' => 'Otsikko',
);
