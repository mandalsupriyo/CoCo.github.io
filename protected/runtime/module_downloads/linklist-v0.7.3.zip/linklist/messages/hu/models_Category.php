<?php
return array (
  'Description' => 'Leírás',
  'Sort Order' => 'Rendezési sorrend',
  'Title' => 'Cím',
);
