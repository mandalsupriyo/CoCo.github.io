<?php
return array (
  'Category' => 'Kategória',
  'Description' => 'Leírás',
  'Sort Order' => 'Rendezési sorrend',
  'Title' => 'Cím',
);
