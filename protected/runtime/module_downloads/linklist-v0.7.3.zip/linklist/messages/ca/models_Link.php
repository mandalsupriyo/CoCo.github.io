<?php
return array (
  'Category' => 'Categoria',
  'Description' => 'Descripció',
  'Sort Order' => 'Ordre de classificació',
  'Title' => 'Títol',
);
