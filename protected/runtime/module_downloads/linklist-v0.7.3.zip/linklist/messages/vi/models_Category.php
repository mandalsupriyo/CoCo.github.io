<?php
return array (
  'Description' => 'Miêu tả',
  'Sort Order' => 'Thứ tự sắp xếp',
  'Title' => 'Tiêu đề',
);
