<?php
return array (
  'Category' => 'Nhóm link',
  'Description' => 'Miêu tả',
  'Sort Order' => 'Thứ tự sắp xếp',
  'Title' => 'Tiêu đề',
);
