<?php
return array (
  'Description' => '',
  'Sort Order' => 'ቅደም ተከተል ያስይዙ',
  'Title' => 'ርዕስ',
);
