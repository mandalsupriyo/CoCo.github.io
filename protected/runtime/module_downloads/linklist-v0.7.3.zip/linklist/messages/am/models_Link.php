<?php
return array (
  'Category' => '',
  'Description' => '',
  'Sort Order' => 'ቅደም ተከተል ያስይዙ',
  'Title' => 'ርዕስ',
);
