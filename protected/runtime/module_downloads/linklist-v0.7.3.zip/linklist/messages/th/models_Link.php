<?php
return array (
  'Category' => 'ประเภท',
  'Description' => 'คำอธิบาย',
  'Sort Order' => 'เรียงลำดับ',
  'Title' => 'หัวข้อ',
);
