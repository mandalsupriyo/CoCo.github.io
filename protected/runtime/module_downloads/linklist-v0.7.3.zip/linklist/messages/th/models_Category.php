<?php
return array (
  'Description' => 'คำอธิบาย',
  'Sort Order' => 'เรียงลำดับ',
  'Title' => 'หัวข้อ',
);
