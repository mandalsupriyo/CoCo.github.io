<?php
return array (
  'Description' => 'توضیحات',
  'Sort Order' => 'ترتیب مرتب‌سازی',
  'Title' => 'عنوان',
);
