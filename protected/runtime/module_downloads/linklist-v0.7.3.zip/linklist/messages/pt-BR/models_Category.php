<?php
return array (
  'Description' => 'Descrição',
  'Sort Order' => 'Ordem de Classificação',
  'Title' => 'Título',
);
