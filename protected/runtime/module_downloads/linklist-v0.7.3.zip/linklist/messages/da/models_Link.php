<?php
return array (
  'Category' => '',
  'Description' => 'Beskrivelse',
  'Sort Order' => 'Sorteringsrækkefølge',
  'Title' => 'Titel',
);
