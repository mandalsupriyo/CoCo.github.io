<?php
return array (
  'Category' => 'Kategori',
  'Description' => 'Beskrivelse',
  'Sort Order' => 'Sorteringsrekkefølge',
  'Title' => 'Tittel',
);
