<?php
return array (
  'Description' => 'Beskrivelse',
  'Sort Order' => 'Sorteringsrekkefølge',
  'Title' => 'Tittel',
);
