<?php
return array (
  'Description' => '',
  'Sort Order' => 'Сортувати за номером',
  'Title' => 'Заголовок',
);
