<?php
return array (
  'Category' => '類別',
  'Description' => '',
  'Sort Order' => '',
  'Title' => '標題',
);
