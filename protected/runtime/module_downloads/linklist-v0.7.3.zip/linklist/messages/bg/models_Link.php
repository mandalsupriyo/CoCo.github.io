<?php
return array (
  'Category' => 'Категория',
  'Description' => 'Описание',
  'Sort Order' => 'Сортирай ред',
  'Title' => 'Заглавие',
);
