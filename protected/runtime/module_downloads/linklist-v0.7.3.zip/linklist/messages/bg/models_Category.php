<?php
return array (
  'Description' => 'Описание',
  'Sort Order' => 'Сортирай ред',
  'Title' => 'Заглавие',
);
