# Etherpad Editor

Integrates the common Etherpad-Lite online editor as Notes in Spaces.

### Features

- Collaborative editing on notes in real-time
- See online/offline status of note users
- Individual content colors for every note user
- Get notifications, if users edited a note

`Note:` This module requires an [Etherpad Lite](http://etherpad.org) installation.
