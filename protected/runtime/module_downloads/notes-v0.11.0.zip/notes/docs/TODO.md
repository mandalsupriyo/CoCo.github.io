ToDos / Wishlist
================

- Send activity when note was changed
- Add ability to modify note title
- Add ability to modify user color

- Delete pads also when deleted in humhub
- Delete authors also when deleted in humhub


