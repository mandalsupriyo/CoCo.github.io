## Installation

- Get Etherpad Server up & running <http://etherpad.org>
- Enable the module under `Admin -> Modules -> Etherpad Notes -> Configure`
- Module Configuration
    - Set API Key (Content of file `APIKEY.txt`in your Etherpad Lite installation)
    - Etherpad Url
- Activate the **Notes** module in Space

