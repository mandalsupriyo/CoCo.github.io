<?php

return [
    'API Connection successful!' => '',
    'Could not connect to API!' => '',
    'Current Status:' => '',
    'Editors:' => '',
    'Etherpad API Key' => '',
    'Etherpad URL Domain' => '',
    'If the Etherpad server is not running under the same domain as the HumHub installation, the Etherpad-Lite plugin "ep_auth_session" must be used.' => '',
    'Note' => '',
    'Notes' => '',
    'Notes Module Configuration' => '',
    'Open note' => '',
    'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => '',
    'Plugin Homepage' => '',
    'Save and close' => '',
    'The notes module needs a etherpad server up and running!' => '',
    'There are no notes yet!' => '',
    'Title of your new note' => '',
    'URL to Etherpad' => '',
    'Use Etherpad Plugin: ep_auth_session' => '',
    'e.g. http://yourdomain/pad/' => '',
];
