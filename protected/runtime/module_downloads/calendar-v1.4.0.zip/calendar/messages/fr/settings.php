<?php
return array (
  'Full calendar' => 'Calendrier entier',
  'Participation' => 'Participation',
  'Reminder' => 'Rappel',
);
