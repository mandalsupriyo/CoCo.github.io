<?php
return array (
  'Day' => 'Jour',
  'List' => 'Liste',
  'Month' => 'Mois',
  'Today' => 'Aujourd’hui',
  'Week' => 'Semaine',
  'Year' => 'Année',
);
