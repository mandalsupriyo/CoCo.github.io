<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Ajouter</strong> un nouveau type d\'événement',
  '<strong>Edit</strong> calendar' => '<strong>Éditer</strong> le calendrier',
  '<strong>Edit</strong> event type' => '<strong>Modifier</strong> le type d\'événement',
);
