<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} a annulé l\'événement "{contentTitle}" dans l\'espace {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} a annulé l\'événement "{contentTitle}".',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} vous a ajouté à l\'événement "{contentTitle}".',
  '{displayName} just invited you to event "{contentTitle}".' => '{displayName} vient de vous inviter à l’événement "{contentTitle}".',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} vient de mettre à jour l\'événement "{contentTitle}" dans l\'espace {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} a mis à jour l\'événement {contentTitle}.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} a réouvert l\'événement "{contentTitle}" dans l\'espace {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} a réouvert l\'événement "{contentTitle}"',
);
