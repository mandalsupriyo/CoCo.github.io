<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% a créé l\'événement %contentTitle%.',
);
