<?php
return array (
  'Calendar: Invite' => 'Calendrier : invite',
  'Calendar: attend' => 'Calendrier : participe',
  'Calendar: decline' => 'Calendrier : ne participe pas',
  'Calendar: maybe' => 'Calendrier : participe peut-être',
  'Whenever someone declines to participate in an event.' => 'Lorsque quelqu\'un indique ne pas participer à un événement.',
  'Whenever someone invites to participate in an event.' => 'Lorsque quelqu\'un invite à participer à un événement.',
  'Whenever someone may be participating in an event.' => 'Lorsque quelqu\'un participera peut-être à un événement.',
  'Whenever someone participates in an event.' => 'Lorsque quelqu\'un participe à un événement.',
);
