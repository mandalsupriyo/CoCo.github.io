<?php

return [
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
    'Participants' => '',
];
