<?php

return [
    'Additional information' => '',
    'All' => '',
    'Attend' => '',
    'Decline' => '',
    'Filter' => '',
    'Maybe' => '',
    'Participants' => '',
    'You are invited, please select your role:' => '',
];
