<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrar</strong> eventos',
  '<strong>Select</strong> calendars' => '<strong>Seleccionar</strong> calendários',
  'Followed spaces' => 'Espaços seguidos',
  'Followed users' => 'Pessoas seguidas',
  'I\'m attending' => 'Vou',
  'My events' => 'Meus eventos',
  'My profile' => 'Meu perfil',
  'My spaces' => 'Meus espaços',
);
