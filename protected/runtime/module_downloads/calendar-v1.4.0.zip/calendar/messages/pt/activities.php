<?php
return array (
  'Calendar: Invite' => 'Calendário: Convite',
  'Calendar: attend' => 'Calendário: participar',
  'Calendar: decline' => 'Calendário: recusar',
  'Calendar: maybe' => 'Calendário: talvez',
  'Whenever someone declines to participate in an event.' => 'Sempre que alguém recusar participar num evento.',
  'Whenever someone invites to participate in an event.' => 'Sempre que alguém convidar para participar num evento.',
  'Whenever someone may be participating in an event.' => 'Sempre que alguém talvez participe num evento.',
  'Whenever someone participates in an event.' => 'Sempre que alguém participe num evento.',
);
