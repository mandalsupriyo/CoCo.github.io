<?php
return array (
  'Additional information' => 'Informação adicional',
  'All' => 'Todos',
  'Attend' => 'Participar',
  'Decline' => 'Recusar',
  'Filter' => 'Filtro',
  'Maybe' => 'Talvez',
  'Participants' => 'Participantes',
  'You are invited, please select your role:' => 'Estás convidado, por favor seleciona o papel:',
);
