<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Começando</strong> em {date}',
  'Additional information:' => 'Informação adicional:',
  'Location:' => 'Local:',
  'Organized by {userName}' => 'Organizado por {userName}',
  'View Online: {url}' => 'Ver Online: {url}',
);
