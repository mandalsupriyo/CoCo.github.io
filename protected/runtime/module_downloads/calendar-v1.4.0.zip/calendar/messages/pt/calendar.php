<?php
return array (
  'Day' => 'Dia',
  'List' => 'Lista',
  'Month' => 'Mês',
  'Today' => 'Hoje',
  'Week' => 'Semana',
  'Year' => 'Ano',
);
