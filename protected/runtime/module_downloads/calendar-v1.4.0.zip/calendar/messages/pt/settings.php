<?php

return [
    'Participation' => 'Participação',
    'Reminder' => 'Lembrete',
    'Full calendar' => '',
];
