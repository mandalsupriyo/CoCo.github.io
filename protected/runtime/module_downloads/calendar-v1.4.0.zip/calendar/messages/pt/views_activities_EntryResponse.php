<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% não vai participar em %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% vai participar em %contentTitle%.',
  '%displayName% is invited to %contentTitle%.' => '%displayName% está convidado a participar em %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% talvez participe em %contentTitle%.',
);
