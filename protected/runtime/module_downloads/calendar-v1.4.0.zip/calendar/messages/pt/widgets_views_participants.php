<?php
return array (
  ':count Attending' => ':count Participam',
  ':count Declined' => ':count Recusaram',
  ':count Invited' => ':count Convidados',
  ':count Undecided' => ':count Indecisos',
  'Participants' => 'Participantes',
);
