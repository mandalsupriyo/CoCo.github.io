<?php
return array (
  'Allows the user to create new calendar entries' => 'Permite à pessoa criar novas entradas de calendário',
  'Allows the user to edit/delete existing calendar entries' => 'Permite à pessoa editar/apagar entradas de calendário existentes',
  'Create entry' => 'Criar entrada',
  'Manage entries' => 'Gerir entradas',
);
