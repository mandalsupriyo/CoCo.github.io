<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Kezdés:</strong> {date}',
  'Additional information:' => 'További információ:',
  'Location:' => 'Elhelyezkedés:',
  'Organized by {userName}' => 'Szervező: {userName}',
  'View Online: {url}' => 'Online megtekintés: {url}',
);
