<?php
return array (
  'Day' => 'Nap',
  'List' => 'Lista',
  'Month' => 'Hónap',
  'Today' => 'Ma',
  'Week' => 'Hét',
  'Year' => 'Év',
);
