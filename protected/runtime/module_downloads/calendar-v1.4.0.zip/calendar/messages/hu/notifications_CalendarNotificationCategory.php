<?php
return array (
  'Calendar' => 'Naptár',
  'Receive Calendar related Notifications.' => 'Naptárral kapcsolatos értesítések fogadása.',
);
