<?php
return array (
  'Calendar: Invite' => 'Naptár: Meghívás',
  'Calendar: attend' => 'Naptár: részvétel',
  'Calendar: decline' => 'Naptár: elutasítás',
  'Calendar: maybe' => 'Naptár: talán',
  'Whenever someone declines to participate in an event.' => 'Amikor valaki megtagadja, hogy részt vegyen egy eseményen.',
  'Whenever someone invites to participate in an event.' => 'Amikor valaki meghív egy eseményre.',
  'Whenever someone may be participating in an event.' => 'Amikor valaki talán részt vesz egy eseményen.',
  'Whenever someone participates in an event.' => 'Amikor valaki részt vesz egy eseményen.',
);
