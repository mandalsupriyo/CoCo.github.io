<?php
return array (
  'Calendars' => 'Naptárak',
  'Defaults' => 'Alapértelmezett',
  'Event Types' => 'Eseménytípusok',
  'Snippet' => 'Kódrészlet (snippet)',
);
