<?php
return array (
  'Full calendar' => 'Teljes naptár',
  'Participation' => 'Részvétel',
  'Reminder' => 'Emlékeztető',
);
