<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Zaczyna się</strong> {date}',
  'Additional information:' => 'Dodatkowe informacje:',
  'Location:' => 'Miejsce:',
  'Organized by {userName}' => 'Dodane przez {userName}',
  'View Online: {url}' => 'Zobacz online: {url}',
);
