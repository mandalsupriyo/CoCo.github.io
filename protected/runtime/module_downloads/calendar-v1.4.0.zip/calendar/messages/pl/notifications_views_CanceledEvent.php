<?php

return [
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} odwołał/a wydarzenie "{contentTitle}" w przestrzeni {spaceName}.',
    '{displayName} canceled event "{contentTitle}".' => '{displayName} odwołał/a wydarzenie "{contentTitle}".',
    '{displayName} just added you to event "{contentTitle}".' => '{displayName} dodał/a Cię do wydarzenia "{contentTitle}".',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} zaktualizował/a wydarzenie "{contentTitle}" w strefie {spaceName}.',
    '{displayName} just updated event {contentTitle}.' => '{displayName} zaktualizował/a wydarzenie {contentTitle}.',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} wznowił/a wydarzenie "{contentTitle}" w strefie {spaceName}.',
    '{displayName} reopened event "{contentTitle}".' => '{displayName} wznowił/a wydarzenie "{contentTitle}".',
    '{displayName} just invited you to event "{contentTitle}".' => '',
];
