<?php

return [
    'Participation' => 'Uczestnictwo',
    'Reminder' => 'Przypomnienia',
    'Full calendar' => '',
];
