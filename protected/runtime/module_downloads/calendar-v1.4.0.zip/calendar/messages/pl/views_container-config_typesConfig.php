<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Stwórz</strong> nowy typ wydarzeń',
  '<strong>Edit</strong> calendar' => '<strong>edytuj</strong> kalendarz',
  '<strong>Edit</strong> event type' => '<strong>Edytuj</strong> typ wydarzeń',
);
