<?php

return [
    'Calendar: attend' => 'Kalendarz: potwierdź obecność',
    'Calendar: decline' => 'Kalendarz: odmów',
    'Calendar: maybe' => 'Kalendarz: może',
    'Whenever someone declines to participate in an event.' => 'Każdorazowo gdy ktoś odmówi uczestnictwa w wydarzeniu.',
    'Whenever someone may be participating in an event.' => 'Każdorazowo gdy ktoś może uczestniczyć w wydarzeniu.',
    'Whenever someone participates in an event.' => 'Każdorazowo gdy ktoś będzie uczestniczył w wydarzeniu.',
    'Calendar: Invite' => '',
    'Whenever someone invites to participate in an event.' => '',
];
