<?php
return array (
  'Day' => 'Dzień',
  'List' => 'Lista',
  'Month' => 'Miesiąc',
  'Today' => 'Dziś',
  'Week' => 'Tydzień',
  'Year' => 'Rok',
);
