<?php
return array (
  'Full calendar' => 'Calendario completo',
  'Participation' => 'Participación',
  'Reminder' => 'Recordatorio',
);
