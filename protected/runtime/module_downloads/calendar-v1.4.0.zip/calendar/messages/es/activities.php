<?php
return array (
  'Calendar: Invite' => 'Calendario: Invitación',
  'Calendar: attend' => 'Calendario: asistir',
  'Calendar: decline' => 'Calendario: rechazar',
  'Calendar: maybe' => 'Calendario: quizá',
  'Whenever someone declines to participate in an event.' => 'Cuando alguien rechaza participar en un evento.',
  'Whenever someone invites to participate in an event.' => 'Cuando alguien invita a participar en un evento.',
  'Whenever someone may be participating in an event.' => 'Cuando alguien quizá participe en un evento.',
  'Whenever someone participates in an event.' => 'Cuando alguien participa en un evento.',
);
