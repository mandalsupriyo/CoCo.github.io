<?php
return array (
  'Day' => 'Día',
  'List' => 'Lista',
  'Month' => 'Mes',
  'Today' => 'Hoy',
  'Week' => 'Semana',
  'Year' => 'Año',
);
