<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% no puede asistir a %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% está asistiendo a %contentTitle%.',
  '%displayName% is invited to %contentTitle%.' => '%displayName% está invitado a %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% puede que asista a %contentTitle%.',
);
