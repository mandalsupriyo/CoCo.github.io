<?php
return array (
  'Additional information' => 'Información Adicional',
  'All' => 'Todos',
  'Attend' => 'Asistir',
  'Decline' => 'No asistir',
  'Filter' => 'Filtrar',
  'Maybe' => 'Tal vez',
  'Participants' => 'Participantes',
  'You are invited, please select your role:' => 'Estas invitado. Por favor elige tu papel:',
);
