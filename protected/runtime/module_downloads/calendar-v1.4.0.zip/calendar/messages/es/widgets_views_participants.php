<?php
return array (
  ':count Attending' => ':count van a asistir',
  ':count Declined' => ':count han rechazado asistir',
  ':count Invited' => ':count invitados',
  ':count Undecided' => ':count están indecisos',
  'Participants' => 'Participantes',
);
