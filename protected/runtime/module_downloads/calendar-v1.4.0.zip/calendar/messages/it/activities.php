<?php

return [
    'Calendar: attend' => 'Partecipo',
    'Calendar: decline' => 'Declino',
    'Calendar: maybe' => 'Forse',
    'Whenever someone declines to participate in an event.' => 'Ogni volta che qualcuno rinuncia a partecipare ad un evento',
    'Whenever someone may be participating in an event.' => 'Ogni volta che qualcuno potrebbe partecipare ad un evento',
    'Whenever someone participates in an event.' => 'Ogni volta che qualcuno effettivamente partecipa ad un evento',
    'Calendar: Invite' => '',
    'Whenever someone invites to participate in an event.' => '',
];
