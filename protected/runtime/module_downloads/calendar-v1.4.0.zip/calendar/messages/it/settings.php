<?php

return [
    'Participation' => 'Partecipazione',
    'Reminder' => 'Promemoria',
    'Full calendar' => '',
];
