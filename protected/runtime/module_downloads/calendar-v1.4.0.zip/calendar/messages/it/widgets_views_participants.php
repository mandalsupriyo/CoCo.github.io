<?php

return [
    'Participants' => 'Partecipanti',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
