<?php
return array (
  'Day' => 'Giorno',
  'List' => 'Lista',
  'Month' => 'Mese',
  'Today' => 'Oggi',
  'Week' => 'Settimana',
  'Year' => 'Anno',
);
