<?php

return [
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} ha cancellato l\'evento "{contentTitle}" nello spazio {spaceName}.',
    '{displayName} canceled event "{contentTitle}".' => '{displayName} ha cancellato l\'evento "{contentTitle}".',
    '{displayName} just added you to event "{contentTitle}".' => '{displayName} ti ha appena aggiunto all\'evento "{contentTitle}".',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} ha aggiornato l\'evento  "{contentTitle}" nello spazio {spaceName}.',
    '{displayName} just updated event {contentTitle}.' => '{displayName} ha appena aggiornato l\'evento {contentTitle}.',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} ha riaperto l\'evento "{contentTitle}" nello spazio {spaceName}.',
    '{displayName} reopened event "{contentTitle}".' => '{displayName} ha riaperto l\'evento "{contentTitle}".',
    '{displayName} just invited you to event "{contentTitle}".' => '',
];
