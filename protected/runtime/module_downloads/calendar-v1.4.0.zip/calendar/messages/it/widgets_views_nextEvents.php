<?php
return array (
  '<strong>Upcoming</strong> events ' => 'Eventi <strong>imminenti</strong>',
  'Open Calendar' => 'Apri Calendario',
);
