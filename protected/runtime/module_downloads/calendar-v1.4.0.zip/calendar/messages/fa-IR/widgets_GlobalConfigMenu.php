<?php

return [
    'Defaults' => 'مقادیر پیش‌فرض',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
