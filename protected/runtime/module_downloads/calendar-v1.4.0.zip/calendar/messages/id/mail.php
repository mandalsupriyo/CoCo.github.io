<?php

return [
    '<strong>Starting</strong> {date}' => '',
    'Additional information:' => '',
    'Location:' => '',
    'Organized by {userName}' => '',
    'View Online: {url}' => '',
];
