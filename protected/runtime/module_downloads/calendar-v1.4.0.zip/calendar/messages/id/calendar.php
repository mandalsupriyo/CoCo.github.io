<?php

return [
    'Day' => '',
    'List' => '',
    'Month' => '',
    'Today' => '',
    'Week' => '',
    'Year' => '',
];
