<?php
return array (
  'Calendar' => 'kalender',
  'Receive Calendar related Notifications.' => '',
);
