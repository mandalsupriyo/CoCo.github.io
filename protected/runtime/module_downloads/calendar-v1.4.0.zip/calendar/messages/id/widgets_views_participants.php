<?php

return [
    'Participants' => 'Partisipasi',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
