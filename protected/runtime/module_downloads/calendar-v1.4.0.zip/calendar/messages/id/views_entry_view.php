<?php
return array (
  'Additional information' => '',
  'All' => '',
  'Attend' => 'Hadir',
  'Decline' => 'Batal',
  'Filter' => 'Filter',
  'Maybe' => 'Mungkin',
  'Participants' => 'Partisipasi',
  'You are invited, please select your role:' => '',
);
