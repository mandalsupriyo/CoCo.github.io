<?php
return array (
  'Calendar' => 'Календар',
  'Receive Calendar related Notifications.' => 'Получавайте известия, свързани с календара.',
);
