<?php
return array (
  'Day' => 'Ден',
  'List' => 'Списък',
  'Month' => 'Месец',
  'Today' => 'Днес',
  'Week' => 'Седмица',
  'Year' => 'Година',
);
