<?php

return [
    '%displayName% cannot attend %contentTitle%.' => '%displayName% не може да присъства на %contentTitle%.',
    '%displayName% is attending %contentTitle%.' => '%displayName% присъства на %contentTitle%.',
    '%displayName% might be attending %contentTitle%.' => '%displayName% може да присъства на %contentTitle%.',
    '%displayName% is invited to %contentTitle%.' => '',
];
