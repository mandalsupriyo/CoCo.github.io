<?php

return [
    'Participation' => 'Участие',
    'Reminder' => 'Напомняне',
    'Full calendar' => '',
];
