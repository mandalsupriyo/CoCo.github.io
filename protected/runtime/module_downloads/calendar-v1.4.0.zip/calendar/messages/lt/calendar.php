<?php
return array (
  'Day' => '',
  'List' => 'Sarašas',
  'Month' => '',
  'Today' => '',
  'Week' => '',
  'Year' => '',
);
