<?php
return array (
  'Additional information' => '',
  'All' => 'Visi',
  'Attend' => 'Dalyvauti',
  'Decline' => 'Atmesti',
  'Filter' => 'Filtras',
  'Maybe' => 'Galbūt',
  'Participants' => 'Dalyviai',
  'You are invited, please select your role:' => '',
);
