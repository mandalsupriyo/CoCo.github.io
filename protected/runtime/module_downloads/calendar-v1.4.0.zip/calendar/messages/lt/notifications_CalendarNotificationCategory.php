<?php
return array (
  'Calendar' => 'Kalendorius',
  'Receive Calendar related Notifications.' => '',
);
