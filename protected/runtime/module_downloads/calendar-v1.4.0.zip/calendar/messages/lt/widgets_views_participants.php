<?php

return [
    'Participants' => 'Dalyviai',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
