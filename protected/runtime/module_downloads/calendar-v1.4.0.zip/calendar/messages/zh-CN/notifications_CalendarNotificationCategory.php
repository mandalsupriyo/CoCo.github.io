<?php
return array (
  'Calendar' => '日历',
  'Receive Calendar related Notifications.' => '',
);
