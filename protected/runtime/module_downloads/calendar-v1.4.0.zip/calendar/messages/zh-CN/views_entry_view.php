<?php
return array (
  'Additional information' => '',
  'All' => '所有',
  'Attend' => '参加',
  'Decline' => '拒绝',
  'Filter' => '筛选',
  'Maybe' => '可能',
  'Participants' => '',
  'You are invited, please select your role:' => '',
);
