<?php

return [
    'Defaults' => '默认',
    'Calendars' => '',
    'Event Types' => '',
    'Snippet' => '',
];
