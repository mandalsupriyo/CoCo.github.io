<?php

return [
    'Defaults' => 'Varsayılan',
    'Event Types' => 'Etkinlik Türleri',
    'Calendars' => '',
    'Snippet' => '',
];
