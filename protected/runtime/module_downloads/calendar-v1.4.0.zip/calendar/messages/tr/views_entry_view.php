<?php
return array (
  'Additional information' => 'Ek bilgi',
  'All' => 'Hepsi',
  'Attend' => 'Katılıyorum',
  'Decline' => 'Katılmıyorum',
  'Filter' => 'Filtre',
  'Maybe' => 'Belki',
  'Participants' => 'Katılımcılar',
  'You are invited, please select your role:' => '',
);
