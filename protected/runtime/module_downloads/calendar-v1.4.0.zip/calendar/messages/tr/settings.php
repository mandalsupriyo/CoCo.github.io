<?php

return [
    'Participation' => 'Katılım',
    'Reminder' => 'Hatırlatıcı',
    'Full calendar' => '',
];
