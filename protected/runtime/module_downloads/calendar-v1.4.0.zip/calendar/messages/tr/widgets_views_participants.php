<?php

return [
    'Participants' => 'Katılımcılar',
    ':count Attending' => '',
    ':count Declined' => '',
    ':count Invited' => '',
    ':count Undecided' => '',
];
