<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 *
 */

/**
 * Created by PhpStorm.
 * User: buddha
 * Date: 23.07.2017
 * Time: 22:55
 */

namespace humhub\modules\calendar\widgets;


use humhub\components\Widget;
use yii\data\ActiveDataProvider;

class CalendarTypeListView extends Widget
{
    public function run()
    {

    }
}