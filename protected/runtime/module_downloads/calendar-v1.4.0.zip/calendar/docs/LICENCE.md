# Licences

- HumHub licences at: https://www.humhub.com/licences

- Calendar UI is based on FullCalendar (http://arshaw.com/fullcalendar/)