[![Test Status](https://github.com/humhub/tasks/workflows/PHP%20Codeception%20Tests/badge.svg)](https://github.com/humhub/tasks/actions)

Tasks Module
==============

Simple task manager for spaces.


For more  informations visit:
<https://github.com/humhub/humhub-modules-tasks>
