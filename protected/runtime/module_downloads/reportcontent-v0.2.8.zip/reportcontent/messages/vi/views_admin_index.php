<?php
return array (
  'Here you can manage reported users posts.' => 'Tại đây bạn có thể quản lý các bài post bị tố cáo',
);
