<?php
return array (
  'Doesn\'t belong to space' => 'Không thuộc về diễn đàn',
  'Offensive' => 'Phản cảm',
  'Spam' => 'SPAM',
);
