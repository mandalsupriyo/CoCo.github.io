<?php

return [
    'Approve' => 'Duyệt',
    'Cancel' => 'Hủy',
    'Content' => 'Nội dung',
    'Do you really want to approve this post?' => 'Bạn thực sự muốn duyệt bài post này?',
    'Reason' => 'Lý do',
    'Reporter' => 'Người tố cáo',
    'There are no reported posts.' => 'Không có bài post nào bị tố cáo.',
    '<strong>Approve</strong> content' => '',
    'Review' => '',
];
