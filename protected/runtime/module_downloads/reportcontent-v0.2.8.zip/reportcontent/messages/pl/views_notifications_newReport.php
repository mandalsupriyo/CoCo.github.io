<?php
return array (
  'An user has reported your post as offensive.' => 'Użytkownik zgłosił Twoją treść jako obraźliwą.',
  'An user has reported your post as spam.' => 'Użytkownik zgłosił Twoją treść jako spam.',
  'An user has reported your post for not belonging to the space.' => 'Użytkownik zgłosił Twoją treść jako nie należącą do strefy.',
);
