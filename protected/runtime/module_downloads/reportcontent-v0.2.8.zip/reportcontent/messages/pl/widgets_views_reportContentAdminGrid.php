<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Zatwieredź</strong> zawartość',
  'Approve' => 'Zatwierdź',
  'Cancel' => 'Anuluj',
  'Content' => 'Treść',
  'Do you really want to approve this post?' => 'Na pewno chcesz zatwierdzić ten wpis?',
  'Reason' => 'Powód',
  'Reporter' => 'Zgłaszający',
  'Review' => 'Przeglądaj',
  'There are no reported posts.' => 'Brak zgłoszonych treści.',
);
