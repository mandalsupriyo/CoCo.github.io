<?php

return [
    'Approve' => 'Hyväksy',
    'Cancel' => 'Peruuta',
    'Content' => 'Sisältö',
    'Do you really want to approve this post?' => 'Haluatko todella hyväksyä tämän viestin?',
    'Reason' => 'Syy',
    'Reporter' => 'Ilmoittaja',
    'There are no reported posts.' => 'Ilmoitettuja julkaisuja ei tällä hetkellä ole.',
    '<strong>Approve</strong> content' => '',
    'Review' => '',
];
