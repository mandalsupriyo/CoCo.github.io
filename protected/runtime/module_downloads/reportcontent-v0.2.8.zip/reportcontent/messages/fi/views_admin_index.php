<?php
return array (
  'Here you can manage reported users posts.' => 'Täällä voit hallita käyttäjien ilmoittamia julkaisuja .',
);
