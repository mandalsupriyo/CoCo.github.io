<?php
return array (
  'Doesn\'t belong to space' => 'Ei kuulu tälle sivulle',
  'Offensive' => 'Luokkaava',
  'Spam' => 'Roskaposti',
);
