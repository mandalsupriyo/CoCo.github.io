<?php

return [
    'Manage <strong>reported posts</strong>' => 'Hallitse <strong>ilmoitettuja julkaisuja</strong>',
    'Please provide a reason, why you want to report this content.' => 'Anna syitä, miksi haluat tehdä ilmoituksen tästä julkaisusta.',
    'Reported posts' => 'Ilmoitetut julkausut',
    'Why do you want to report this post?' => 'Miksi haluat tehdä ilmoituksen tästä julkaisusta?',
    'created by :displayName' => 'luonut: displayName',
];
