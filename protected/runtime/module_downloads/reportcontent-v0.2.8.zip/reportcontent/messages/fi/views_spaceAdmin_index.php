<?php
return array (
  'Here you can manage reported posts for this space.' => 'Täällä voit hallita tämän sivun ilmoitettuja julkaisuja.',
);
