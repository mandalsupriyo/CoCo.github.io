<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%DisplayName% on ilmoittanut %contentTitle% loukkaavaksi.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% on ilmoittanut %contentTitle% roskapostiksi.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% on ilmoittanut %contentTitle% kuulumattomaksi tälle sivulle.',
);
