<?php

return [
    'Cancel' => 'Atšaukti',
    'Content' => 'Turinys',
    'Reason' => 'Priežastis',
    'Reporter' => 'Pranešėjas',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Review' => '',
    'There are no reported posts.' => '',
];
