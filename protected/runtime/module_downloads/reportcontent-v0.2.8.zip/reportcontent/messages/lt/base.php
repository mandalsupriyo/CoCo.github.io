<?php

return [
    'Manage <strong>reported posts</strong>' => 'Tvarkyti <strong>skelbimus, apie kuriuos pranešė</strong>',
    'Reported posts' => 'Skelbimai, apie kuriuos pranešė',
    'Please provide a reason, why you want to report this content.' => '',
    'Why do you want to report this post?' => '',
    'created by :displayName' => '',
];
