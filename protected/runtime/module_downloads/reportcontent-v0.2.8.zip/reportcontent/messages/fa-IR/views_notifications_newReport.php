<?php
return array (
  'An user has reported your post as offensive.' => 'یک کاربر پست شما را توهین‌آمیز اعلام کرده‌است.',
  'An user has reported your post as spam.' => 'یک کاربر پست شما را اسپم اعلام کرده‌است.',
  'An user has reported your post for not belonging to the space.' => 'یک کاربر اعلام کرده‌است که پست شما مربوط به این انجمن نیست.',
);
