<?php

return [
    'Manage <strong>reported posts</strong>' => 'مدیریت <strong>پست‌های گزارش‌شده</strong>',
    'Reported posts' => 'پست‌های گزارش‌شده',
    'Why do you want to report this post?' => 'چرا مي خواهيد اين مطلب را گزارش دهيد؟',
    'created by :displayName' => 'displayName : ساخته شده توسط',
    'Please provide a reason, why you want to report this content.' => '',
];
