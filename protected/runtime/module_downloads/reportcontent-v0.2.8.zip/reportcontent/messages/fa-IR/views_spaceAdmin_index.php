<?php
return array (
  'Here you can manage reported posts for this space.' => 'شما می‌توانید در این قسمت پست‌های گزارش‌شده‌ برای این انجمن را مدیریت کنید.',
);
