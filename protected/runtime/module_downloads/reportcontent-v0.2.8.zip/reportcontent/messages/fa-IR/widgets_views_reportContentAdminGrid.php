<?php

return [
    'Cancel' => 'لغو',
    'Content' => 'محتوا',
    'Reason' => 'علت',
    'Reporter' => 'گزارش‌کننده',
    'There are no reported posts.' => 'هيچ مطلب گزارش شده اي موجود نيست',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Review' => '',
];
