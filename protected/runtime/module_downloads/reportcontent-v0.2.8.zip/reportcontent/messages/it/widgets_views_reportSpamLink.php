<?php
return array (
  'Does not belong here' => 'Non é attinente. ',
  'Help Us Understand What\'s Happening' => 'Aiutaci a capire cosa è successo',
  'It\'s offensive' => 'È offensivo',
  'It\'s spam' => 'Spam! ',
  'Report post' => 'Segnala post',
  'Submit' => 'Invia',
);
