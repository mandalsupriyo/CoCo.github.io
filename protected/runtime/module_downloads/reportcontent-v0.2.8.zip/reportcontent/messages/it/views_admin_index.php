<?php
return array (
  'Here you can manage reported users posts.' => 'Qui puoi gestire i post segnalati dagli utenti.',
);
