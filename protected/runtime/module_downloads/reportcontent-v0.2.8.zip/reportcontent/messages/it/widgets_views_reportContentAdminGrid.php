<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Approva</strong> contenuto',
  'Approve' => 'Approva',
  'Cancel' => 'Annulla',
  'Content' => 'Contenuti',
  'Do you really want to approve this post?' => 'Vuoi approvare questo post?',
  'Reason' => 'Motivo',
  'Reporter' => 'Segnalatore',
  'Review' => 'Revisione',
  'There are no reported posts.' => 'Non ci sono post segnalati',
);
