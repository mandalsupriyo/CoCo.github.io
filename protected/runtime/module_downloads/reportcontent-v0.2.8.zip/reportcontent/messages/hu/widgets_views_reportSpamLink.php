<?php
return array (
  'Does not belong here' => 'Nem ide tartozik',
  'Help Us Understand What\'s Happening' => 'Segíts megértenünk, hogy mi történik',
  'It\'s offensive' => 'Sértő',
  'It\'s spam' => 'Spam',
  'Report post' => 'Bejegyzés jelentése',
  'Submit' => 'Elküldés',
);
