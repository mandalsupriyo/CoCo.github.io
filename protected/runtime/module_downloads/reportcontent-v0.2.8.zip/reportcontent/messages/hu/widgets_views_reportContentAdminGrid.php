<?php
return array (
  '<strong>Approve</strong> content' => 'Tartalom <strong>Jóváhagyása</strong>',
  'Approve' => 'Elfogadás',
  'Cancel' => 'Mégsem',
  'Content' => 'Tartalom',
  'Do you really want to approve this post?' => 'Tényleg jóváhagyod ezt a bejegyzést?',
  'Reason' => 'Ok',
  'Reporter' => 'Bejelentő',
  'Review' => 'Előnézet',
  'There are no reported posts.' => 'Nincsenek jelentett bejegyzések.',
);
