<?php
return array (
  'Here you can manage reported users posts.' => 'Itt kezelheted a jelentett felhasználók hozzászólásait.',
);
