<?php

return [
    'Manage <strong>reported posts</strong>' => 'Gestion des <strong>contenus signalés</strong>',
    'Please provide a reason, why you want to report this content.' => 'Merci de fournir une raison, pourquoi vous souhaitez signaler ce contenu.',
    'Reported posts' => 'Contenus signalés',
    'Why do you want to report this post?' => 'Pourquoi voulez-vous signaler ce contenu ?',
    'created by :displayName' => 'créé par :displayName',
];
