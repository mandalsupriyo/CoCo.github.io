<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Approuver</strong> ce contenu',
  'Approve' => 'Approuver',
  'Cancel' => 'Annuler',
  'Content' => 'Contenu',
  'Do you really want to approve this post?' => 'Voulez-vous vraiment approuver cette publication ?',
  'Reason' => 'Raison',
  'Reporter' => 'Signaler',
  'Review' => 'Examiner',
  'There are no reported posts.' => 'Il n\'y a aucune publication signalée.',
);
