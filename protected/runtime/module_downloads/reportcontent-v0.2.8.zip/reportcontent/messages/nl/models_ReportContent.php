<?php
return array (
  'Doesn\'t belong to space' => 'Hoort niet thuis in deze space',
  'Offensive' => 'Beledigend',
  'Spam' => 'Spam',
);
