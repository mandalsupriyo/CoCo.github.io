<?php
return array (
  'Here you can manage reported users posts.' => 'Hier kun je gerapporteerde posts beheren.',
);
