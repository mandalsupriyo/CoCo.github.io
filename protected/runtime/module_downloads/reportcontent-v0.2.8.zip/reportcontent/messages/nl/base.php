<?php

return [
    'Manage <strong>reported posts</strong>' => '<strong>Gerapporteerde</strong> berichten',
    'Please provide a reason, why you want to report this content.' => 'Geeft een redenen op waarom u dit bericht wilt rapporteren.',
    'Reported posts' => 'Gerapporteerde berichten',
    'Why do you want to report this post?' => 'Waarom wil je dit bericht rapporteren?',
    'created by :displayName' => 'gemaakt door :displayname',
];
