<?php
return array (
  '<strong>Approve</strong> content' => 'Inhoud <strong>goedkeuren</strong>',
  'Approve' => 'Goedkeuren',
  'Cancel' => 'Annuleren',
  'Content' => 'Content',
  'Do you really want to approve this post?' => 'Wilt u dit bericht goedkeuren?',
  'Reason' => 'Reden',
  'Reporter' => 'Rapporteur',
  'Review' => 'Recensie',
  'There are no reported posts.' => 'Er zijn geen gerapporteerde berichten.',
);
