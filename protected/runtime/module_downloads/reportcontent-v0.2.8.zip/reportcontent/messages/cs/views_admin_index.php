<?php
return array (
  'Here you can manage reported users posts.' => 'Zde můžete spravovat nahlášené příspěvky uživatelů.',
);
