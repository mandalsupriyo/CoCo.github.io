<?php
return array (
  'An user has reported your post as offensive.' => 'Uživatel nahlásil Váš příspěvek jako urážlivý.',
  'An user has reported your post as spam.' => 'Uživatel nahlásil Váš příspěvek jako nevyžádaný.',
  'An user has reported your post for not belonging to the space.' => 'Uživatel nahlásil váš příspěvek z důvodu, že nepatří do prostoru.',
);
