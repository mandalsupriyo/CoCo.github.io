<?php

return [
    'Approve' => 'Povolit',
    'Cancel' => 'Zrušit',
    'Content' => 'Příspěvky',
    'Do you really want to approve this post?' => 'Opravdu chcete tento příspěvek schválit?',
    'Reason' => 'Důvod',
    'Reporter' => 'Nahlašovatel',
    'There are no reported posts.' => 'Neexistují žádné hlášené příspěvky.',
    '<strong>Approve</strong> content' => '',
    'Review' => '',
];
