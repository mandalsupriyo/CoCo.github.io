<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% nahlásil příspěvek %contentTitle% jako urážlivý.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% nahlásil příspěvek %contentTitle% jako nevyžádaný.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% nahlásil příspěvek %contentTitle% , že nepatří do prostoru.',
);
