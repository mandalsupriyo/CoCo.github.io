<?php
return array (
  '<strong>Approve</strong> content' => '',
  'Approve' => '',
  'Cancel' => 'Anulo',
  'Content' => 'Përmbajtja',
  'Do you really want to approve this post?' => '',
  'Reason' => '',
  'Reporter' => '',
  'Review' => '',
  'There are no reported posts.' => '',
);
