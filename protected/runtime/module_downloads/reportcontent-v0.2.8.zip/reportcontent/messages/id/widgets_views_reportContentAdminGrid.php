<?php

return [
    'Cancel' => 'Batal',
    'Content' => 'Konten',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Reason' => '',
    'Reporter' => '',
    'Review' => '',
    'There are no reported posts.' => '',
];
