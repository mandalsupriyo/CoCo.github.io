<?php
return array (
  '<strong>Approve</strong> content' => '<strong> Aprovar </strong> conteúdo',
  'Approve' => 'Aprovar',
  'Cancel' => 'Cancelar',
  'Content' => 'Conteúdo',
  'Do you really want to approve this post?' => 'Você realmente quer aprovar esta postagem?',
  'Reason' => 'Motivo',
  'Reporter' => 'Relator',
  'Review' => 'Análise',
  'There are no reported posts.' => 'Não há postagens denunciadas.',
);
