<?php
return array (
  'Here you can manage reported posts for this space.' => 'Aqui você pode gerenciar posts reportados deste espaço.',
);
