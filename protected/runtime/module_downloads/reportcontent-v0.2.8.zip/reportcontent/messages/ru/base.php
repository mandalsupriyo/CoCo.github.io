<?php

return [
    'Manage <strong>reported posts</strong>' => 'Управление <strong>репортами</strong>',
    'Reported posts' => 'Репорты',
    'Why do you want to report this post?' => 'Почему вы хотите написать этот репорт?',
    'created by :displayName' => 'создано :displayName',
    'Please provide a reason, why you want to report this content.' => '',
];
