<?php

return [
    'Cancel' => 'Отменить',
    'Content' => 'Содержание',
    'Reason' => 'Причина',
    'Reporter' => 'Репорт',
    'There are no reported posts.' => 'Здесь не зарегистрировано ни одного сообщения.',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Review' => '',
];
