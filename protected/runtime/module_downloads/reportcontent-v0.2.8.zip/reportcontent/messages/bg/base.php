<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Управление на <strong>докладвани публикации</strong>',
  'Please provide a reason, why you want to report this content.' => 'Моля, посочете причина, поради която искате да подадете сигнал за това съдържание.',
  'Reported posts' => 'Докладвани публикации',
  'Why do you want to report this post?' => 'Защо искате да докладвате за тази публикация?',
  'created by :displayName' => 'създадена от :displayName',
);
