<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Одобри</strong> съдържание',
  'Approve' => 'Одобри',
  'Cancel' => 'Отказ',
  'Content' => 'Съдържание',
  'Do you really want to approve this post?' => 'Наистина ли искате да одобрите тази публикация?',
  'Reason' => 'Причина',
  'Reporter' => 'Докладчик',
  'Review' => 'Преглед',
  'There are no reported posts.' => 'Няма докладвани публикации.',
);
