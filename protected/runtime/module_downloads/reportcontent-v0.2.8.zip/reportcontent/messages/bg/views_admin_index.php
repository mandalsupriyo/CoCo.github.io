<?php
return array (
  'Here you can manage reported users posts.' => 'Тук можете да управлявате съобщенията на докладвани потребители.',
);
