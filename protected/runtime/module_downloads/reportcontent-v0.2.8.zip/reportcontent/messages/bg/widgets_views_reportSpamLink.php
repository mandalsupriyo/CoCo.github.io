<?php
return array (
  'Does not belong here' => 'Не принадлежи тук',
  'Help Us Understand What\'s Happening' => 'Помогнете ни да разберем какво се случва',
  'It\'s offensive' => 'Обидно е',
  'It\'s spam' => 'Това е спам',
  'Report post' => 'Докладвай публикация',
  'Submit' => 'Изпращане',
);
