<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% съобщи %contentTitle% като обидно.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% съобщи %contentTitle% като спам.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% съобщи %contentTitle% за непринадлежност към раздела.',
);
