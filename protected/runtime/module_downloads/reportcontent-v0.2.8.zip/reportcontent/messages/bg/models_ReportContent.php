<?php
return array (
  'Doesn\'t belong to space' => 'Не принадлежи на раздела',
  'Offensive' => 'Обидна',
  'Spam' => 'Спам',
);
