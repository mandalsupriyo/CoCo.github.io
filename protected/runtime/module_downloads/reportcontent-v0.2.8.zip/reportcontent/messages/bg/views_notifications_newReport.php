<?php
return array (
  'An user has reported your post as offensive.' => 'Потребител е отчел публикацията ви като обидна.',
  'An user has reported your post as spam.' => 'Потребител е докладвал публикацията ви като спам.',
  'An user has reported your post for not belonging to the space.' => 'Потребител е докладвал за публикацията ви, че не принадлежи към раздела.',
);
