<?php
return array (
  'Here you can manage reported posts for this space.' => 'Тук можете да управлявате докладвани публикации за този раздел.',
);
