<?php
return array (
  'Here you can manage reported posts for this space.' => 'Aquí puedes administrar las entradas reportadas para este espacio.',
);
