<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Aprobar</strong> el contenido',
  'Approve' => 'Aprobar',
  'Cancel' => 'Cancelar',
  'Content' => 'Contenido',
  'Do you really want to approve this post?' => '¿De verdad quieres aprobar este post?',
  'Reason' => 'Razón',
  'Reporter' => 'Reportador',
  'Review' => 'Revisar',
  'There are no reported posts.' => 'No hay posts reportados.',
);
