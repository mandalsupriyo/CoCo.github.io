<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% ha reportado %contentTitle% como ofensiva.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% ha reportado %contentTitle% como spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% ha reportado %contentTitle% por no pertenecer al espacio.',
);
