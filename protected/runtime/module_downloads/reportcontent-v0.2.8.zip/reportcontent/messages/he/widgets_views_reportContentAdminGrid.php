<?php
return array (
  '<strong>Approve</strong> content' => '',
  'Approve' => '',
  'Cancel' => 'ביטול',
  'Content' => 'תוכן',
  'Do you really want to approve this post?' => '',
  'Reason' => '',
  'Reporter' => '',
  'Review' => '',
  'There are no reported posts.' => '',
);
