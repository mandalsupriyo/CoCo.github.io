<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Approve</strong> content',
  'Approve' => 'Odobri',
  'Cancel' => 'Poništi',
  'Content' => 'Sadržaj',
  'Do you really want to approve this post?' => 'Zaista želite odobriti ovu objavu?',
  'Reason' => 'Razlog',
  'Reporter' => 'Prijavitelj',
  'Review' => 'Pregled',
  'There are no reported posts.' => 'Nema prijavljenih objava.',
);
