<?php

return [
    'Manage <strong>reported posts</strong>' => 'Upravljaj <strong>prijavljenim objavama</strong>',
    'Please provide a reason, why you want to report this content.' => 'Navedite razlog zašto želite prijaviti ovaj sadržaj.',
    'Reported posts' => 'Prijavljene objave',
    'Why do you want to report this post?' => 'Zašto želite prijaviti ovu objavu?',
    'created by :displayName' => 'kreirano od :displayName',
];
