<?php
return array (
  'An user has reported your post as offensive.' => 'Korisnik je prijavio vašu objavu kao uvredljivu.',
  'An user has reported your post as spam.' => 'Korisnik je prijavio vašu objavu kao neželjeni sadržaj.',
  'An user has reported your post for not belonging to the space.' => 'Korisnik je prijavio vašu objavu jer ne pripada u prostor.',
);
