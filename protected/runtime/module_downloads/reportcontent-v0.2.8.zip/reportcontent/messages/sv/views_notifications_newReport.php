<?php
return array (
  'An user has reported your post as offensive.' => 'En användare har rapporterat ditt inlägg som förolämpande.',
  'An user has reported your post as spam.' => 'En användare har rapporterat ditt inlägg som skräppost.',
  'An user has reported your post for not belonging to the space.' => 'En användare har rapporterat ditt inlägg som irrelevant för forumet.',
);
