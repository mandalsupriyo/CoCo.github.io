<?php
return array (
  'Here you can manage reported users posts.' => 'Här kan du hantera inlägg från anmälda användare.',
);
