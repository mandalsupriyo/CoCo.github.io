<?php
return array (
  'Doesn\'t belong to space' => 'Hör inte hemma i detta forum',
  'Offensive' => 'Förolämpande',
  'Spam' => 'Skräp',
);
