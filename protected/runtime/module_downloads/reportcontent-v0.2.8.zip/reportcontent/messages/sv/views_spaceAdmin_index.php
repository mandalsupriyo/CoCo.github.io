<?php
return array (
  'Here you can manage reported posts for this space.' => 'Här kan du hantera anmälda inlägg för detta forum.',
);
