<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Godkänn</strong> innehåll',
  'Approve' => 'Godkänn',
  'Cancel' => 'Avbryt',
  'Content' => 'Innehåll',
  'Do you really want to approve this post?' => 'Vill du verkligen godkänna detta inlägg?',
  'Reason' => 'Anledning',
  'Reporter' => 'Anmält av',
  'Review' => 'Granska',
  'There are no reported posts.' => 'Det finns inga anmälda inlägg.',
);
