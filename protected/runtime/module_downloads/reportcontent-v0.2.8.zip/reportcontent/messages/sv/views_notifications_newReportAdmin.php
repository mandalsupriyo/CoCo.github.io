<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% har rapporterat %contentTitle% som stötande.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% har rapporterat %contentTitle% som spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% har rapporterat %contentTitle% som att inte tillhöra forumet.',
);
