<?php
return array (
  'Does not belong here' => 'Hör inte hemma här',
  'Help Us Understand What\'s Happening' => 'Hjälp oss förstå vad som är problemet',
  'It\'s offensive' => 'Det är förolämpande',
  'It\'s spam' => 'Det är skräppost',
  'Report post' => 'Rapportera inlägget',
  'Submit' => 'Skicka',
);
