<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Hantera <strong>anmälda inlägg </strong>',
  'Please provide a reason, why you want to report this content.' => 'Ge en anledning till att du vill anmäla detta innehåll.',
  'Reported posts' => 'Anmälda inlägg',
  'Why do you want to report this post?' => 'Varför vill du anmäla detta inlägg?',
  'created by :displayName' => 'skapad av :displayName',
);
