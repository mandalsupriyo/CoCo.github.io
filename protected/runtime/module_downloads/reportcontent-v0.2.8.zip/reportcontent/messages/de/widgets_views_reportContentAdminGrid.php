<?php
return array (
  '<strong>Approve</strong> content' => '<strong>Inhalt</strong> freigeben',
  'Approve' => 'Genehmigen',
  'Cancel' => 'Abbrechen',
  'Content' => 'Inhalt',
  'Do you really want to approve this post?' => 'Möchtest du diesen Beitrag wirklich genehmigen?',
  'Reason' => 'Grund',
  'Reporter' => 'Melder',
  'Review' => 'Überprüfen',
  'There are no reported posts.' => 'Keine gemeldeten Beiträge.',
);
