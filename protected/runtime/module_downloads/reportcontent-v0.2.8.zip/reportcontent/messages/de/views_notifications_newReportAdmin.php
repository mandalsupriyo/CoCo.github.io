<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% hat %contentTitle% als beleidigend gemeldet.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% hat %contentTitle% als Spam gemeldet.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% hat %contentTitle% gemeldet, weil er nicht in diesen Space gehört.',
);
