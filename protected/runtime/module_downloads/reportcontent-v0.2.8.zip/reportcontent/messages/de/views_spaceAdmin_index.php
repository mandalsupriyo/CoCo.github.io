<?php
return array (
  'Here you can manage reported posts for this space.' => 'Hier kannst Du gemeldete Beiträge für diesen Space verwalten.',
);
