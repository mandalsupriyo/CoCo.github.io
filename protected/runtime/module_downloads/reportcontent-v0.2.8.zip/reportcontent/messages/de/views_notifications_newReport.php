<?php
return array (
  'An user has reported your post as offensive.' => 'Ein Benutzer hat Deinen Beitrag als beleidigend gemeldet.',
  'An user has reported your post as spam.' => 'Ein Benutzer hat Deinen Beitrag als Spam gemeldet.',
  'An user has reported your post for not belonging to the space.' => 'Ein Benutzer hat Deinen Beitrag gemeldet, weil er nicht in diesen Space gehört.',
);
