<?php

return [
    'Cancel' => 'Cancel·la',
    'Content' => 'Contingut',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Reason' => '',
    'Reporter' => '',
    'Review' => '',
    'There are no reported posts.' => '',
];
