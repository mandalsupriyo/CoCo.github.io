<?php
return array (
  'Doesn\'t belong to space' => '',
  'Offensive' => '',
  'Spam' => '',
);
