<?php

return [
    'Manage <strong>reported posts</strong>' => '',
    'Please provide a reason, why you want to report this content.' => '',
    'Reported posts' => '',
    'Why do you want to report this post?' => '',
    'created by :displayName' => '',
];
