<?php

return [
    'Approve' => 'Onayla',
    'Cancel' => 'İptal',
    'Content' => 'İçerik',
    'Do you really want to approve this post?' => 'Bu gönderiyi gerçekten onaylamak istiyor musunuz?',
    'Reason' => 'Neden',
    'Reporter' => 'Tarafından',
    'There are no reported posts.' => 'Rapor edilen gönderi bulunamadı.',
    '<strong>Approve</strong> content' => '',
    'Review' => '',
];
