<?php

return [
    'Manage <strong>reported posts</strong>' => 'Raporlanan gönderileri yönet',
    'Please provide a reason, why you want to report this content.' => 'Lütfen bu içeriği neden bildirmek istediğinizi belirtin.',
    'Reported posts' => 'Raporlanan mesajlar',
    'Why do you want to report this post?' => 'Neden raporlamak istiyorsun?',
    'created by :displayName' => 'oluşturan :displayName',
];
