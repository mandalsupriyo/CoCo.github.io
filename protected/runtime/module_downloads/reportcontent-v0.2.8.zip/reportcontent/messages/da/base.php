<?php

return [
    'Manage <strong>reported posts</strong>' => 'Administrer <strong>anmeldte opslag</strong>',
    'Reported posts' => 'Anmeldte opslag',
    'Why do you want to report this post?' => 'Hvorfor vil du anmelde dette opslag?',
    'created by :displayName' => 'Lavet af :displayName',
    'Please provide a reason, why you want to report this content.' => '',
];
