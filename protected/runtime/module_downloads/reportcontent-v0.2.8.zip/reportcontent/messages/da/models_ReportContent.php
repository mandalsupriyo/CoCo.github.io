<?php
return array (
  'Doesn\'t belong to space' => 'Hører ikke til på siden',
  'Offensive' => 'Angribende',
  'Spam' => 'Spam',
);
