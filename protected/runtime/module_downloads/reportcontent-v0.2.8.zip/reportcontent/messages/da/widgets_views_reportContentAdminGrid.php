<?php

return [
    'Cancel' => 'Afbryd',
    'Content' => 'Indhold',
    'Reason' => 'Grundlag',
    'Reporter' => 'Anmelder',
    'There are no reported posts.' => 'Der er ingen rapporterede opslag',
    '<strong>Approve</strong> content' => '',
    'Approve' => '',
    'Do you really want to approve this post?' => '',
    'Review' => '',
];
