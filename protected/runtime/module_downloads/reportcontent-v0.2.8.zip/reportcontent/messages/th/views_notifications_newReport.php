<?php
return array (
  'An user has reported your post as offensive.' => 'ผู้ใช้รายหนึ่งรายงานว่าโพสต์ของคุณไม่เหมาะสม',
  'An user has reported your post as spam.' => 'ผู้ใช้รายงานว่าโพสต์ของคุณเป็นสแปม',
  'An user has reported your post for not belonging to the space.' => 'ผู้ใช้รายหนึ่งรายงานโพสต์ของคุณเนื่องจากไม่อยู่ใน Space',
);
