<?php
return array (
  'Manage <strong>reported posts</strong>' => 'จัดการ <strong>โพสต์ที่รายงาน</strong>',
  'Please provide a reason, why you want to report this content.' => 'โปรดระบุเหตุผล เหตุใดคุณจึงต้องการรายงานเนื้อหานี้',
  'Reported posts' => 'โพสต์ที่รายงาน',
  'Why do you want to report this post?' => 'เหตุใดคุณจึงต้องการรายงานโพสต์นี้',
  'created by :displayName' => 'สร้างโดย :displayName',
);
