<?php
return array (
  'Here you can manage reported users posts.' => 'คุณสามารถจัดการโพสต์ของผู้ใช้ที่รายงานได้ที่นี่',
);
