<?php
return array (
  'Doesn\'t belong to space' => 'ไม่อยู่ในอวกาศ',
  'Offensive' => 'เป็นที่น่ารังเกียจ',
  'Spam' => 'สแปม',
);
