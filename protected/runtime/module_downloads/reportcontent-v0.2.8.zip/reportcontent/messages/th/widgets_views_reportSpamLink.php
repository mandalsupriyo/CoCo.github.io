<?php
return array (
  'Does not belong here' => 'ไม่ได้อยู่ที่นี่',
  'Help Us Understand What\'s Happening' => 'ช่วยให้เราเข้าใจว่าเกิดอะไรขึ้น',
  'It\'s offensive' => 'มันน่ารังเกียจ',
  'It\'s spam' => 'มันเป็นสแปม',
  'Report post' => 'รายงานโพสต์',
  'Submit' => 'ส่ง',
);
