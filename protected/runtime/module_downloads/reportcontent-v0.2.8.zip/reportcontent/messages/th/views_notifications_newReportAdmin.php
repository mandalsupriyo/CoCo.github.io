<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% ได้รายงาน %contentTitle% ว่าไม่เหมาะสม',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% รายงานว่า %contentTitle% เป็นสแปม',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% ได้รายงาน %contentTitle% เนื่องจากไม่ได้อยู่ในพื้นที่',
);
