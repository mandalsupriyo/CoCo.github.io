<?php
return array (
  'Here you can manage reported posts for this space.' => 'ที่นี่คุณสามารถจัดการโพสต์ที่รายงานสำหรับพื้นที่นี้',
);
