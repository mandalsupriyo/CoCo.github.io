<?php
return array (
  '<strong>Approve</strong> content' => '<strong>อนุมัติ</strong> เนื้อหา',
  'Approve' => 'อนุมัติ',
  'Cancel' => 'ยกเลิก',
  'Content' => 'เนื้อหา',
  'Do you really want to approve this post?' => 'คุณต้องการอนุมัติโพสต์นี้จริงหรือ',
  'Reason' => 'เหตุผล',
  'Reporter' => 'ผู้สื่อข่าว',
  'Review' => 'รีวิว',
  'There are no reported posts.' => 'ไม่มีโพสต์รายงาน',
);
