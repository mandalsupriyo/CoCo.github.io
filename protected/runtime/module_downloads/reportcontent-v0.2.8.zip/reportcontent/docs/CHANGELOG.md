Changelog
=========

0.2.8 (April 14, 2022)
----------------------
- Enh #4823: Remove CHTML/CActiveForm usages

0.2.7  (October 18, 2020)
-----------------------
- Fix: Removed usage of legacy richtext
- Enh: Reworked report overview
- Enh: Updated translations

0.2.6  (July 2, 2018)
-----------------------
- Fix #31: Reporting a post creates HTTP500 status and breaks admin overview of reported posts
- Chg: Updated min HumHub version to 1.3

0.2.5  (July 2, 2018)
-----------------------
- Fix: PHP 7.2 compatibility issues


0.2.4 -  (April 17, 2018)
----------------------
- Fix #21 Report notification not displayed
