<?php

return [
    'modules' => ['breakingnews'],
    'fixtures' => ['default']
];
