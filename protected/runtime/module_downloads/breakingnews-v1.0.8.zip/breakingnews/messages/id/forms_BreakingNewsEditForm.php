<?php
return array (
  'Active' => 'Aktif',
  'Mark as unseen for all users' => 'Tandai agar tak terlihat untuk semua pengguna',
  'Message' => 'Pesan',
  'Title' => 'Judul',
);
