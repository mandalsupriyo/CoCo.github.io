<?php

return [
    'Back to modules' => 'Kembali ke modul',
    'Breaking News Configuration' => 'Pengaturan Kabar terbaru ',
    'Note: You can use markdown syntax.' => 'Catatan: Kamu dapat menggunakan markdown syntax',
];
