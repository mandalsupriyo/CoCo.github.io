<?php

return [
    'Close' => '',
];
