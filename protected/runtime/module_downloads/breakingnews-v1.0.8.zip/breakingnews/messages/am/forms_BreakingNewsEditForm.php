<?php
return array (
  'Active' => '',
  'Mark as unseen for all users' => '',
  'Message' => 'መልዕክት',
  'Title' => 'ርዕስ',
);
