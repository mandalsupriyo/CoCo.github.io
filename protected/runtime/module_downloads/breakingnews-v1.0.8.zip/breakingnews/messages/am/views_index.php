<?php
return array (
  'Close' => 'ዝጋ',
);
