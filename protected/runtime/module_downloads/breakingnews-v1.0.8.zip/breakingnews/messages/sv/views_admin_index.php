<?php

return [
    'Back to modules' => 'Tillbaka till moduler',
    'Breaking News Configuration' => 'Inställningar för Senaste nytt',
    'Note: You can use markdown syntax.' => 'Obs: du kan använda markdown syntax',
];
