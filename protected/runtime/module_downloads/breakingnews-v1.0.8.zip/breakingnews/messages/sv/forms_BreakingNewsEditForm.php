<?php
return array (
  'Active' => 'Aktiv',
  'Mark as unseen for all users' => 'Markera som inte läst för alla användare',
  'Message' => 'Meddelande',
  'Title' => 'Rubrik',
);
