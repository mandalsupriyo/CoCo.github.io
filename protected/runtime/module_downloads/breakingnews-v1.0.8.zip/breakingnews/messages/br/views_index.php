<?php
return array (
  'Close' => 'Serriñ',
);
