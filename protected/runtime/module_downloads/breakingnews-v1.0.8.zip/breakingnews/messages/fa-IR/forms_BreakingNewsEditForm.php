<?php
return array (
  'Active' => 'فعال',
  'Mark as unseen for all users' => 'برای تمام کاربران به صورت مشاهده‌نشده نمایش‌بده',
  'Message' => 'پیام',
  'Title' => 'عنوان',
);
