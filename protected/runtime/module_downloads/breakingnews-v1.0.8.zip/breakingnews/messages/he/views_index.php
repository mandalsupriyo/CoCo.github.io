<?php
return array (
  'Close' => 'סגור',
);
