<?php

return [
    'Back to modules' => 'Επιστροφή στις ενότητες',
    'Breaking News Configuration' => 'Εκτακτες Ειδήσεις Διαμόρφωσης',
    'Note: You can use markdown syntax.' => 'Σημείωση: Μπορείτε να χρησιμοποιήσετε σύνταξη αντιστοίχισης.',
];
