<?php
return array (
  'Active' => 'Ενεργός',
  'Mark as unseen for all users' => 'Σημειώστε ως αόρατο για όλους τους χρήστες',
  'Message' => 'Μήνυμα',
  'Title' => 'Τίτλος',
);
