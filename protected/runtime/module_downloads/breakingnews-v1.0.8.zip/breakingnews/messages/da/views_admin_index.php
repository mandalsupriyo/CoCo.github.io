<?php

return [
    'Back to modules' => 'Tilbage til moduler',
    'Breaking News Configuration' => 'Breaking News Konfiguration',
    'Note: You can use markdown syntax.' => 'Bemærk: Du kan bruge markdown syntaks.',
];
