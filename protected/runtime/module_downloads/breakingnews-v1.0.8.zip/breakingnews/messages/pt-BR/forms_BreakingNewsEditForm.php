<?php
return array (
  'Active' => 'Ativo',
  'Mark as unseen for all users' => 'Marcar como não-visto para todos usuários',
  'Message' => 'Mensagem',
  'Title' => 'Título',
);
