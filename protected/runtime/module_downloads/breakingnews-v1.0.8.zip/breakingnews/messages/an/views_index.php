<?php
return array (
  'Close' => 'Zarrar',
);
