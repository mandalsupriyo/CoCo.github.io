<?php

return [
    'Back to modules' => 'Volver a Módulos',
    'Breaking News Configuration' => 'Configuración de noticias de última hora',
    'Note: You can use markdown syntax.' => 'Nota: Puedes usar sintaxis markdown.',
];
