<?php
return array (
  'Active' => '在線',
  'Mark as unseen for all users' => '設定成所有用戶未讀',
  'Message' => '訊息',
  'Title' => '標題',
);
