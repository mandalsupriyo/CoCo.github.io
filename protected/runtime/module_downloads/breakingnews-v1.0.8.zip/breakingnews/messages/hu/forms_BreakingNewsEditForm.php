<?php
return array (
  'Active' => 'Aktív',
  'Mark as unseen for all users' => 'Jelöld olvasatlannak minden felhasználónak',
  'Message' => 'Üzenet',
  'Title' => 'Tárgy',
);
