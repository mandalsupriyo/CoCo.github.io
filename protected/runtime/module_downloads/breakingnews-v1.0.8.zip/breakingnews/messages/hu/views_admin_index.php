<?php

return [
    'Back to modules' => 'Vissza a modulokhoz',
    'Breaking News Configuration' => 'Fontos hírek beállítása',
    'Note: You can use markdown syntax.' => 'Megjegyzés: Használhatsz "markdown" szintaxisokat.',
];
