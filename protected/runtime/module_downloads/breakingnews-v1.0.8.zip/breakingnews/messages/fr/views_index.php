<?php
return array (
  'Close' => 'Fermer',
);
