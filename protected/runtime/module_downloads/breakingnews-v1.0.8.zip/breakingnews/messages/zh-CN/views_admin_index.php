<?php

return [
    'Back to modules' => '返回模块',
    'Breaking News Configuration' => '弹出新闻配置',
    'Note: You can use markdown syntax.' => '提示：你可以使用标签语法(html标签)。',
];
