<?php
return array (
  'Active' => 'Hoạt động',
  'Mark as unseen for all users' => 'Đánh dấu \'chưa xem\' cho tất cả người dùng',
  'Message' => 'Tin nhắn',
  'Title' => 'Tiêu đề',
);
