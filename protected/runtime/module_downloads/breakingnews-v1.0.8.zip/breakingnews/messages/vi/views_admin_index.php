<?php

return [
    'Back to modules' => 'Trở lại Modules',
    'Breaking News Configuration' => 'Cấu hình tin nóng',
    'Note: You can use markdown syntax.' => 'Ghi chú: Bạn có thể dùng cú pháp ngôn ngữ Markdown',
];
