<?php

return [
    'Back to modules' => 'Indietro ai moduli',
    'Breaking News Configuration' => 'Blocca nuove configurazioni',
    'Note: You can use markdown syntax.' => 'Nota: Puoi usare la sintassi marcata.',
];
