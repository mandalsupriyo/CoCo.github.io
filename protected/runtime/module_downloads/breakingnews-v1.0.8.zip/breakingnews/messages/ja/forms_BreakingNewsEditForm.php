<?php
return array (
  'Active' => 'アクティブ',
  'Mark as unseen for all users' => 'すべてのユーザーに見えない状態としてマーク',
  'Message' => 'メッセージ',
  'Title' => 'タイトル',
);
