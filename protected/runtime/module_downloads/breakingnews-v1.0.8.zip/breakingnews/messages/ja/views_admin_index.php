<?php

return [
    'Back to modules' => 'モジュールへ戻る',
    'Breaking News Configuration' => 'ニュース速報の設定',
    'Note: You can use markdown syntax.' => '注：マークダウン構文を使用することができます。',
];
