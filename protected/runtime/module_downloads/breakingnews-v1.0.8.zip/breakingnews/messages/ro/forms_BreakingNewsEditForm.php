<?php
return array (
  'Active' => 'Active',
  'Mark as unseen for all users' => 'Marchează ca și nevăzute pentru toți utilizatorii',
  'Message' => 'Mesaj',
  'Title' => 'Titlu',
);
