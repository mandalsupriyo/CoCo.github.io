<?php

return [
    'Back to modules' => 'Wróć do modułów',
    'Breaking News Configuration' => 'Konfiguracja Breaking News',
    'Note: You can use markdown syntax.' => 'Przypis: Możesz użyć składni markdown.',
];
