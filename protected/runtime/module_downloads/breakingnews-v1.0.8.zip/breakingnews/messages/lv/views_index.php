<?php
return array (
  'Close' => 'Aizvērt',
);
