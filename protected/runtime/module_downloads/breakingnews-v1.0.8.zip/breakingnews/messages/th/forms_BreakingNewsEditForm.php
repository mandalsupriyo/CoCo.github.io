<?php
return array (
  'Active' => 'คล่องแคล่ว',
  'Mark as unseen for all users' => 'ทำเครื่องหมายว่ามองไม่เห็นสำหรับผู้ใช้ทั้งหมด',
  'Message' => 'ข้อความ',
  'Title' => 'หัวข้อ',
);
