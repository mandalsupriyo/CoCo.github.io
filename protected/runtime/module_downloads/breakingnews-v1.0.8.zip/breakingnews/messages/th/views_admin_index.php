<?php

return [
    'Back to modules' => 'กลับไปที่โมดูล',
    'Breaking News Configuration' => 'การกำหนดค่าข่าวด่วน',
    'Note: You can use markdown syntax.' => 'หมายเหตุ: คุณสามารถใช้ไวยากรณ์มาร์คดาวน์',
];
