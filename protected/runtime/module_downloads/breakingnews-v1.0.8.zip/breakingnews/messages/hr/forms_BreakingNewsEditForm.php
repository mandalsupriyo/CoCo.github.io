<?php
return array (
  'Active' => 'Aktivno',
  'Mark as unseen for all users' => 'Označi kao nepročitano za sve korisnike',
  'Message' => 'Poruka',
  'Title' => 'Naziv',
);
