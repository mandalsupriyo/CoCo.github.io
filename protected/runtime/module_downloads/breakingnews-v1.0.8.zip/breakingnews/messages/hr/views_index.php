<?php
return array (
  'Close' => 'Zatvori',
);
