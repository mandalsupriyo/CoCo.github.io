<?php

return [
    'Back to modules' => 'Povratak na module',
    'Breaking News Configuration' => 'Izvanredne vijesti - konfiguracija',
    'Note: You can use markdown syntax.' => 'Napomena: Možete upotrijebiti sintaksu za označavanje.',
];
