<?php
return array (
  'Active' => 'معروض',
  'Mark as unseen for all users' => 'جعل الخبر جديد على كل الأعضاء',
  'Message' => 'النص',
  'Title' => 'العنوان',
);
