<?php

return [
    'Back to modules' => 'العودة للموديولات',
    'Breaking News Configuration' => 'خصائص الأخبار العاجلة',
    'Note: You can use markdown syntax.' => 'ملاحظة: يمكنك استعمال التأثيرات على النص',
];
