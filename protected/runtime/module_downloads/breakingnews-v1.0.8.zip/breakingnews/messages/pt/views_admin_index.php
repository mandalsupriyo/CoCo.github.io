<?php
return array (
  'Back to modules' => 'Voltar para os módulos',
  'Breaking News Configuration' => 'Configurações de  Notícias de Última Hora',
  'Note: You can use markdown syntax.' => 'Nota: Podes utilizar a sintaxe markdown.',
);
