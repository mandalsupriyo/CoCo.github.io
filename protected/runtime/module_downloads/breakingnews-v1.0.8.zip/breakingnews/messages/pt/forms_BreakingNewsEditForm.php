<?php
return array (
  'Active' => 'Ativado',
  'Mark as unseen for all users' => 'Marcar como invisível para todas as pessoas',
  'Message' => 'Mensagem',
  'Title' => 'Título',
);
