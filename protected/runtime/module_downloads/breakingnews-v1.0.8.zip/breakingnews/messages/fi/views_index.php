<?php
return array (
  'Close' => 'Sulje',
);
