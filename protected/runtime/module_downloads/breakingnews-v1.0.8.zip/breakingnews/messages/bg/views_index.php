<?php
return array (
  'Close' => 'Затвори',
);
