<?php

return [
    'Back to modules' => 'Върни се при модулите',
    'Breaking News Configuration' => 'Конфигуриране на актуални новини',
    'Note: You can use markdown syntax.' => 'Забележка: Можете да използвате маркдаун синтаксис.',
];
