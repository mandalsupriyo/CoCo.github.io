<?php
return array (
  'Active' => 'Активен',
  'Mark as unseen for all users' => 'Маркирайте като невидим за всички потребители',
  'Message' => 'Съобщение',
  'Title' => 'Заглавие',
);
