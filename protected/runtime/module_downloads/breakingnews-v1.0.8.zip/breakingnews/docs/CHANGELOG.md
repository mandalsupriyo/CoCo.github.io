Changelog
=========

1.0.8 (November 14, 2022)
-------------------------
- Enh #20: Display breaking news to only the members of certain groups


1.0.7 (November 14, 2022)
-------------------------
- Enh #24: Show breaking news on any page (not only the dashboard)


1.0.5 (March 25, 2022)
----------------------
- Fix #16: Fix file attaching to news message


1.0.4 (June 18, 2021)
---------------------
- Fix #10: Fix content loading on PJAX request
