# Breaking News

The Breaking News module allows administrators to create a popup notice in form of a lightbox. The lightbox is displayed directly after login. This way, very important information can be prominently displayed to users. In addition, the module allows different messages to be delivered to different user groups. This enables the targeted delivery of information to the user groups that are really supposed to receive it. 
